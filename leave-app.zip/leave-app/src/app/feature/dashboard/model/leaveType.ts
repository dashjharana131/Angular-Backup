
export class LeaveType {
    leaveTypeId: number;
    type_name: string;
    status: number;

    constructor(id) {
        this.leaveTypeId = id;
    }
}
