import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events-main',
  templateUrl: './events-main.component.html',
  styleUrls: ['./events-main.component.css']
})
export class EventsMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
