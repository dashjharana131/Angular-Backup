import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
//import { DatePickerComponent } from './date-picker/date-picker.component';
//  import { DatePickerComponent } from './date-picker/date-picker.component';
import {CalendarModule} from 'primeng/calendar';
import { FormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    CommonModule,
    CalendarModule,
    FormsModule
    //DatePickerComponent
  ],
  declarations: [],
  exports: [
    CommonModule,
  ]
})
export class SharedModule { }
