import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navnside-wrapper',
  templateUrl: './navnside-wrapper.component.html',
  styleUrls: ['./navnside-wrapper.component.css']
})
export class NavnsideWrapperComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
