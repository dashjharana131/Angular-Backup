export const environment = {
  production: true,
  apiUrl: 'https://employeeleave.herokuapp.com/api',
};
