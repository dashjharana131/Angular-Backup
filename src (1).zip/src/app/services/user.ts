export interface User {
    firstname: string,
    lastname: string,
    password: string,
    email: string,
    dateofbirth: string,
    phone: string
}