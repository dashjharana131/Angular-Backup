import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';



@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  firstApiurl: string = 'http://10.117.189.34:8080/loan/mortgage/register';


  usersign(): Observable<User[]> {
    return this.http.get<User[]>(this.firstApiurl);
  }


}