import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innerhome',
  templateUrl: './innerhome.component.html',
  styleUrls: ['./innerhome.component.css']
})
export class InnerhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
