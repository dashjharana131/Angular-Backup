export interface ISlot {
    id: number,
    name: string,
    status: boolean
}