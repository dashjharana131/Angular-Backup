import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IRequest } from './request';

@Injectable()
export class RequestsService {

    constructor(private http: HttpClient) { }

    url: string = 'http://localhost:3000/requests';

    getAllRequests(user_id): Observable<IRequest[]> {
        return this.http.get<IRequest[]>(this.url + '?user_id=' + user_id);
    }

    submitRequest(data): Observable<IRequest[]> {
        return this.http.post<IRequest[]>(this.url, data);
    }

}