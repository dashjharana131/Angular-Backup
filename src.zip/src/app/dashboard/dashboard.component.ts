import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SlotService } from './slot.service';
import { RequestsService } from './request.service';
import { ISlot } from './slot';
import { IRequest } from './request';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {

  isFormError: boolean = false;
  isFormSuccess: boolean = false;
  isShowSurrender: boolean = false;

  userDetail;
  slots: ISlot[];
  availableSlots: any;
  requests: IRequest[];

  reqCols: any[];
  cities: any[];

  sel_slotId: number = 0;
  sel_slotName: string = '';
  sel_startDate = new Date();
  sel_endDate = new Date();
  sel_day: number = 0;

  constructor(private router: Router, private slotService: SlotService, private requestsService: RequestsService) { }

  ngOnInit() {
    this.availableSlots = [];
    this.getUserDetails();
    this.initGetSlotList();
    this.initGetRequestList();
    this.initAvailableSlots();

    this.reqCols = [
      { field: 'user_id', header: 'Name' },
      { field: 'slot_name', header: 'Slot' },
      { field: 'start_time', header: 'Start Time' },
      { field: 'end_time', header: 'End Time' },
      { field: 'status', header: 'Status' }
    ];
  }

  getUserDetails() {
    if (typeof (Storage) !== "undefined") {
      this.userDetail = JSON.parse(window.localStorage.getItem("user"));
    }
  }

  initGetSlotList() {
    this.slotService.getAllSlots().subscribe(data => {
      this.slots = data;
    });
  }

  initGetRequestList() {
    this.requestsService.getAllRequests(this.userDetail.id).subscribe(data => {
      this.requests = data;
    });
  }

  initAvailableSlots() {
    setTimeout(() => {
      this.slots.filter(slots => {
        if (slots.status == true) {
          this.availableSlots.push(slots);
        }
      })
      console.log('here...');
      console.log(this.availableSlots);
    }, 1000);
  }

  submitRequest() {

    if (this.sel_slotId != 0 && this.sel_day != 0) {
      this.isFormError = false;
      var tempObj = {};
      tempObj['user_id'] = this.userDetail.id;
      tempObj['slot_id'] = this.sel_slotId;
      tempObj['slot_name'] = this.sel_slotName;
      tempObj['duration'] = this.sel_day;
      tempObj['start_time'] = this.sel_startDate;
      tempObj['end_time'] = this.sel_endDate;
      tempObj['status'] = true;
      tempObj['cancel'] = false;

      this.requestsService.submitRequest(tempObj).subscribe(data => {
        if (data != undefined && data != null) {
          setTimeout(() => {
            this.slotService.updateSlotAfterRequest(this.sel_slotId, { "status": false }).subscribe(data => {
              if (data != undefined && data != null) {
                this.isFormSuccess = true;
                this.initGetSlotList();
                this.initGetRequestList();
                this.initAvailableSlots();
              }
            });
          }, 1000);
        }
      })
    } else {
      this.isFormError = true;
    }
  }

  changeSlotDropdown(event) {
    this.sel_slotId = event.target.value;
    this.availableSlots.filter(data => {
      if (data.id == this.sel_slotId) {
        this.sel_slotName = data.name;
      }
    });
    console.log(this.sel_slotId);
    console.log(this.sel_slotName);
  }

  changeDurationDropdown(event) {
    this.sel_day = event.target.value;
    console.log(this.sel_day);
  }

  userLogout() {
    localStorage.removeItem("user");
    this.router.navigate(['/']);
  }

}
