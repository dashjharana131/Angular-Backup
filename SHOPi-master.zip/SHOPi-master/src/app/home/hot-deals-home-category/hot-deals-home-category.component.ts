import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hot-deals-home-category',
  templateUrl: './hot-deals-home-category.component.html',
  styleUrls: ['./hot-deals-home-category.component.scss']
})
export class HotDealsHomeCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
