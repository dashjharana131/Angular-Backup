import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kids-home-category',
  templateUrl: './kids-home-category.component.html',
  styleUrls: ['./kids-home-category.component.scss']
})
export class KidsHomeCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
