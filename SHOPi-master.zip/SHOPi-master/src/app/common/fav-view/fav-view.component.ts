import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fav-view',
  templateUrl: './fav-view.component.html',
  styleUrls: ['./fav-view.component.scss']
})
export class FavViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
