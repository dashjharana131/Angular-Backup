
<script>if(confirm('Would you like to reserve this movie?'))
{
window.location='Login.php';
}else{
window.location='UPDATE.PHP';
}
</script>