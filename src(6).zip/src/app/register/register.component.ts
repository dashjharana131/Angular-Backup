import { Component, OnInit } from '@angular/core';
import { UserDataService } from '../user-data.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm = new FormGroup({
    fullName: new FormControl(''),
    email: new FormControl('', [Validators.email]),
    userName: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    contact: new FormControl(''),
    address: new FormControl(''),
  });
  constructor(private router: Router, private userDataService: UserDataService) { }

  ngOnInit() {
  }

  registerUser(users) {
    console.log('UserForm Details----', this.registerForm.value);
    this.userDataService.registerUser(this.registerForm.value).subscribe((response) => {
      console.log('repsonse ', response);
    });
    console.log('this.userDataService', users);
  }
}
