import { Component, OnInit } from '@angular/core';
import { UserDataService } from '../user-data.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm = new FormGroup({
    userName: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
  });
  userDetails: any = [];
  display: boolean = false;

  constructor(private userDataService: UserDataService, private router: Router) { }

  ngOnInit() {
  }

  /* User login */
  userLogin() {
    this.userDataService.login()
      .subscribe(data => {
        this.userDetails = data
        console.log('Data---', this.userDetails[0].username);
        console.log('User Form Data', this.loginForm.value);
        if (this.loginForm.value.userName == "David" && this.loginForm.value.password == "Sone@11") {
          alert('Logged in successfully');
          this.router.navigateByUrl("/home");
        } else {
          alert('Login failed')
        }
      }, error => console.log('Given Details Not Matching...'))
  }
}
