import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {

  constructor(private http: HttpClient) { }

  /* Service to get user details */
  login() {
    return this.http.get('http://localhost:3000/user')
    // .map((res: Response) => res.json())
    // .catch((error: any) => Observable.throw(error.json().error || 'Server Error'));
  }

  /* Service to register user details */
  registerUser(user) {
    console.log('registerUser---Service', user);
    return this.http.post('http://localhost:3000/user/', user);
  }
}
