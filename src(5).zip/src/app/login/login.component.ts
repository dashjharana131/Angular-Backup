import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { User } from './user';
import { UsersserviceService } from '../services/usersservice.service';


@Component({ templateUrl: 'login.component.html', styleUrls: ['./login.component.css'] })
export class LoginComponent implements OnInit {
  // @Output() isUserLoggedIn: EventEmitter<any> = new EventEmitter<boolean>();
  user: any = User;
  //message: any;
  //subscription: Subscription;
  // loading = false;
  // submitted = false;
  returnUrl: string;
  username: string;
  password: string;
  constructor(
    private router: Router,
    private users: UsersserviceService
  ) { }
  ngOnInit() {
    this.users.isUserLoggedIn && this.router.navigate(['/home']);
  }

  validateUser(arr) {
    return new Promise((resolve, reject) => {
      let valid = false;
      arr.forEach(v => {
        if (v.userName == this.user.userName && v.password == this.user.password) {
          valid = true;
          resolve();
        }
      });
      !valid && reject();
    });
  }
  onSubmit() {
    //this.submitted = true;
    this.users.getUser().subscribe(res => {
      this.validateUser(res).then(r => {
        // this.isUserLoggedIn.emit(true);
        this.router.navigate(['/home']);
        this.users.isUserLoggedIn = true;
      }, e => {
        alert('Username or Password is not valid');
      });
    });
  }
}
