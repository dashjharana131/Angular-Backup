import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { User } from './user';
import { MessageService } from 'primeng/components/common/messageservice';
import { UsersserviceService } from '../services/usersservice.service';

@Component({
  selector: 'app-register',
  templateUrl: 'register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [MessageService]
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  /* loading = false;*/
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router, private http: HttpClient,
    private messageService: MessageService,
    private fetchservice: UsersserviceService) { }
  user: any = User;
  showSuccess() {
    this.messageService.add({ severity: 'success', summary: 'Success Message', detail: 'Registration Done Successfully' });
  }
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      userName: ['', Validators.required],
      userEmail: ['', [Validators.required,]]
    });
  }

  /* convenience getter for easy access to form fields*/
  get f() { return this.registerForm.controls; }

  conformationMsg: string = "New User Added Successfully";
  isAdded: boolean = false;

  onSubmit() {
    this.submitted = true;
    const userObj = {
      "userName": this.registerForm.controls.userName,
      "userEmail": this.registerForm.controls.userEmail,
    }

    this.http.post("http://10.117.189.226:9910/library/registration", userObj).subscribe((res: any) => {
      console.log(res);
    })
    /* this.loading = true;*/
  }
}
