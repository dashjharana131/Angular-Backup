export class User {
    public id: number;
    public userName: string;
    public userEmail: string;
}