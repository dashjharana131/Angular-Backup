import { Component, OnInit } from '@angular/core';
import { UsersserviceService } from '../services/usersservice.service';
import { HttpClient } from '@angular/common/http';
import { MessageService } from 'primeng/components/common/messageservice';
import { Message } from 'primeng/components/common/message';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [MessageService]
})
export class HomeComponent implements OnInit {

  constructor(private bookservice: UsersserviceService, private http: HttpClient, private messageService: MessageService) { }
  msgs: Message[] = [];
  // books = {
  //   travel =[],
  //   novels =[],
  //   health =[],
  //   encyclopedia =[],
  //   science =[],
  // }
  travels = [];
  novelss = [];
  healths = [];
  encyclopedias = [];
  sciences = [];
  ngOnInit() {
    this.bookservice.fetchBooks().subscribe(res => {
      this.travels = res.travel;
      this.novelss = res.novels;
      this.healths = res.health;
      this.encyclopedias = res.encyclopedia;
      this.sciences = res.science;
    })
  }
  showSuccess() {
    this.msgs = [];
    this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Book Donated Successfully' });
  }
}
