import { TestBed } from '@angular/core/testing';

import { UsersserviceService } from './usersservice.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('UsersserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule
    ],
    providers: [
      UsersserviceService,
    ]
  }));

  it('should be created', () => {
    const service: UsersserviceService = TestBed.get(UsersserviceService);
    expect(service).toBeTruthy();
  });
});
