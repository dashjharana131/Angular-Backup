import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsersserviceService {
  apiUrl: string = 'http://10.117.189.226:9910/library/api/login';
  public isUserLoggedIn: boolean = false;
  submitted: boolean;
  userObj: {};
  loading: boolean;

  constructor(private http: HttpClient) { }

  getUser() {
    return this.http.get(this.apiUrl);
  }

  createAccount(obj) {
    return this.http.post(this.apiUrl, obj);
  }
  //Fetch books info
  fetchBooks() {
    return this.http.get("http://localhost:4000/books");
  }
}
