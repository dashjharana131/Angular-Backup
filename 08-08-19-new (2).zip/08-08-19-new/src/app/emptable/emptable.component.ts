import { Component, OnInit } from '@angular/core';
import * as traveldata from '../../assets/json/mapdata.json';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emptable',
  templateUrl: './emptable.component.html',
  styleUrls: ['./emptable.component.css']
})
export class EmptableComponent implements OnInit {
empdata:any;
mylist:any = [];
newAttribute: any;
data: any ;
addemp :any =[];

  constructor(private http:HttpClient,private route:Router) { }

  ngOnInit() {
        this.http.get("http://localhost:3000/MyTravel").subscribe((response) => {
                if (response) {
                    this.data = response;
                    for (let i = 0; i < this.data.EmpData.length; i++) {
                      const element = this.data.EmpData[i];
                      this.addemp.push(element);
                    }
                   console.log(response);
                }
          });
    
    console.log(this.mylist);
  }
  removeemp(languague, index){
    this.data.splice(index, 1);
  }
  updateemp(index) {
      this.route.navigate(['/update',{data:index}]);
          //  return this.http.put("http://localhost:3000/MyTravel" , this.empdata.empname).subscribe((response)=>{
          //     console.log(response);
          //  });
} 

  addFieldValue(emp,i) {
    this.mylist.push(this.newAttribute)
    this.newAttribute = {};
}

}
