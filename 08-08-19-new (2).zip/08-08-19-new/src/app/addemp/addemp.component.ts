import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-addemp',
  templateUrl: './addemp.component.html',
  styleUrls: ['./addemp.component.css']
})
export class AddempComponent implements OnInit {
data: any;
datalength:any;
formvalues:any;
  profileForm = new FormGroup({
    name: new FormControl('',Validators.required),
    mobile: new FormControl('',Validators.required),
    email: new FormControl(''),
  });
  constructor(private http:HttpClient) { }

  ngOnInit() {
  
  }

  onSubmit() {
    console.log(this.profileForm.status)
    if(this.profileForm.status == "VALID"){
      this.http.get("http://localhost:3000/MyTravel").subscribe((response) => {
        if (response) {
            this.datalength = response;
           console.log(this.datalength.length);
           this.formvalues = this.datalength.length;
           this.formvalues = this.profileForm.value;
       var obj ={
            "id":this.datalength.length+1,
            "empname": this.profileForm.value.name,
            "empmobile": this.profileForm.value.mobile,
            "empemail": this.profileForm.value.email,
            "actions": ""
        }
        
          console.log(obj);
          
           console.log(this.formvalues);
           this.http.post("http:localhost:3000/MyTravel",obj).subscribe((response)=>{
              console.log(response);
           });
    }

      });

  }
}

}
