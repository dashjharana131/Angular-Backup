import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-empupdate',
  templateUrl: './empupdate.component.html',
  styleUrls: ['./empupdate.component.css']
})
export class EmpupdateComponent implements OnInit {
data:any;
updateempId:any;
updatedatarecord :any=[]
name:any;
email:any;
phone:any;

  constructor(private route:ActivatedRoute,private http:HttpClient) { }

  ngOnInit() {
    this.updateempId= this.route.snapshot.params.data;
   this.http.get(`http://localhost:3000/MyTravel/${this.updateempId}`).subscribe((response) => {
    if (response) {
        this.data = response;
        // for (let i = 0; i < this.data.length; i++) {
        //    this.updatedatarecord.push(this.data[i]);
          this.name = this.data.name;
          this.email =this.data.email;
          this.phone = this.data.phone;

    }
  
    console.log(this.data);
});
  }


}
