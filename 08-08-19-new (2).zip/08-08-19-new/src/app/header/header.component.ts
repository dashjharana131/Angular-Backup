import { Component, OnInit } from '@angular/core';
import { FormBuilder , FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  // model: any = {};
  // public option = [
  //   {value: "exs", id:"Yes"},
  //   {value: "exn", id:"No"},
  // ]
  registerForm: FormGroup;
  isValid: boolean = true;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      street: ['', Validators.required],
      zip: ['', Validators.required],
      city: ['', Validators.required]
      // address: this.formBuilder.group({
      //   street: [],
      //   zip: [],
      //   city: []
      // })
    });
  }


  onValChange(value){
    console.log(value.target.innerText)
    if(value.target.innerText == "No"){
      console.log("Now hide fristname");
   this.isValid = false;
    }
  }
  
  onSubmit(){
    if (this.registerForm.invalid) {
      return;
  }
  console.log(this.registerForm.value.firstname);

  }
}
