import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup} from '@angular/forms';
import * as jsondata from "../../assets/json/mapdata.json"

@Component({
  selector: 'app-domestic',
  templateUrl: './domestic.component.html',
  styleUrls: ['./domestic.component.css'],
  
})
export class DomesticComponent implements OnInit {
  approvallist : any = [];
  tavellist :any = []
  model: any = {};

  public options = [
    {value: "on", id:"On"},
    {value: "na", id:"NA"},
    {value: "off", id:"Off"},
  ]
  public options5 = [
    {value: "ow", id:"ow"},
    {value: "rt", id:"rt"},
    {value: "mt", id:"mt"},
  ]

  public option = [
    {value: "exs", id:"Yes"},
    {value: "exn", id:"No"},
  ]
//profileForm = new FormGroup({
  //  name = new FormControl('');
  //});
  constructor() { 
    
  }

  ngOnInit() {
    console.log(jsondata);
    let jsontraveldata = jsondata.MyTravel.TravelList;
    let jsonapprovaldata = jsondata.MyTravel.MyApproval; 

    for (let i = 0; i < jsontraveldata.length; i++) {
      const element = jsontraveldata[i];
      this.tavellist.push(element);
    }
    console.log(this.tavellist);
    for (let j = 0; j < jsonapprovaldata.length; j++) {
      const sample = jsonapprovaldata[j];
      this.approvallist.push(sample);
    }
    console.log(this.approvallist);
  }
  removeApprove(traveldata , index ){
    //onclick functions are outside of this.ngOnInit.
    this.tavellist.splice(index, 1);
  }
  onSubmit() {
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.model))
  }
}
