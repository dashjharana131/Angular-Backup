import { Component, OnInit } from '@angular/core';
import * as jsondata from "../../assets/json/mapdata.json";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  approvallist : any = [];
  tavellist :any = []
  constructor() { }

  ngOnInit() {
    console.log(jsondata);
    let jsontraveldata = jsondata.MyTravel.TravelList;
    let jsonapprovaldata = jsondata.MyTravel.MyApproval; 

    for (let i = 0; i < jsontraveldata.length; i++) {
      const element = jsontraveldata[i];
      this.tavellist.push(element);
    }
    console.log(this.tavellist);
    for (let j = 0; j < jsonapprovaldata.length; j++) {
      const sample = jsonapprovaldata[j];
      this.approvallist.push(sample);
    }
    console.log(this.approvallist);
  }
  removeApprove(traveldata , index ){
    //onclick functions are outside of this.ngOnInit.
    this.tavellist.splice(index, 1);
  }

}
