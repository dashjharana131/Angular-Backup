import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DomesticComponent } from './domestic/domestic.component';
import { DashboardComponent } from "./dashboard/dashboard.component";
import { InternationalComponent } from './international/international.component';
import { EmptableComponent } from './emptable/emptable.component';
import { AddempComponent } from './addemp/addemp.component';
import { EmpupdateComponent } from './empupdate/empupdate.component';

const routes: Routes = [
  { path :'domestic' , component: DomesticComponent },
  { path :'international' , component: InternationalComponent },
  { path :'dashboard' , component: DashboardComponent },
  { path :'emptable' , component: EmptableComponent },
  { path :'addemp' , component: AddempComponent},
  { path : 'update' , component:EmpupdateComponent},
  { path : '' , component: EmptableComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
