import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-international',
  templateUrl: './international.component.html',
  styleUrls: ['./international.component.css']
})
export class InternationalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
