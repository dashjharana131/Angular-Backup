import { Component, OnInit , Input} from '@angular/core';
import { DataServiceService } from '../dataService/data-service.service';
@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent implements OnInit {
@Input() labelDrop: string;
@Input() dropItems: any;
  constructor(private dataService:DataServiceService) { }

  ngOnInit() {
  }
 
}
