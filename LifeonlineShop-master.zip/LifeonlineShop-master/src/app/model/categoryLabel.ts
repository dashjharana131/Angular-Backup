export class categoryLabel {
  woman: String;
  man: String;
  bag: String;
  health: String;
  baby: String;
  foods: String;
  footwear: String;
  jewel: String;
  phone: String;
  electronic: String;
}
