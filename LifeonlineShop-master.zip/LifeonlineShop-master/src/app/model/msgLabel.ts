export class msgLabel {
  required: String;
  success: String;
  fail: String;
  pending: String;
  loading: String;
  sorry: String;
  wrong: String;
  submit: String;
  pay: String;
  close: String;
  detail: String;
  addtocart: String;
  remove: String;
  changeFont: String;
  change: String;
}
