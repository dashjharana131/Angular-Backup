export class subCategoryLabel {}
