export class registerLabel {
  name: String;
  phone: String;
  address: String;
  city: String;
  state: String;
  reveive: String;
}
