export class navigationLabel {
  Home: String;
  ContactUs: String;
  AboutUs: String;
  Register: String;
}
