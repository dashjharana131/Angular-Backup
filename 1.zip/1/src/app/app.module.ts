/*
inBuilt modules
*/
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
  /*
  components and  modules
  */
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { EmplistComponent } from './emplist/emplist.component';
/*
Reusable componenets
*/
import { AppInputComponent } from './core/app-input/app-input.component';
import { HeaderComponent } from './core/header/header.component';
import { TablesComponent } from './core/tables/tables.component';

import { AlertMessageComponent } from './core/alert-message/alert-message.component';
import { ButtonComponent } from './core/button/button.component';


@NgModule({
  declarations: [
    AppComponent,
    AppInputComponent,
    LoginComponent,
    HeaderComponent,
    TablesComponent,
    EmplistComponent,
    AlertMessageComponent,
    ButtonComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
