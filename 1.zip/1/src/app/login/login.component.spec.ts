import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms'
import { LoginComponent } from './login.component';
import { AppInputComponent } from '../core/app-input/app-input.component';
import { AlertMessageComponent } from '../core/alert-message/alert-message.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { DataServiceService } from '../core/dataService/data-service.service';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { ActivatedRoute, ActivatedRouteStub } from '../../testing/activated-route-stub';
import { click } from '../../testing/index';

import { Router } from '@angular/router';

let page: Page;
let activatedRoute: ActivatedRouteStub;
let component: LoginComponent;
let fixture: ComponentFixture<LoginComponent>;
describe('LoginComponent', () => {
      let de: DebugElement;
  let el: HTMLElement;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[ ReactiveFormsModule,  RouterTestingModule.withRoutes([]), HttpClientModule ],
      declarations: [ LoginComponent, AppInputComponent, AlertMessageComponent ],
      providers:[DataServiceService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('Should call onSubmit method', () => {
  //   fixture.detectChanges();
  //   spyOn(component,'onLoginSubmit');
  //   el = fixture.debugElement.query(By.css('button')).nativeElement;
  //   el.click();
  //   expect(component.onLoginSubmit).toBeDefined();
  //   expect(component.onLoginSubmit).toHaveBeenCalledTimes(1);
  //  expect(component.loginId).toBeDefined();
  //  expect(component.password).toBeDefined();
   
   
  // });
  it('f function should return values', () => {
    expect(component.f).toBeDefined();
    });
    it('onLoginSubmit function should return values', () => {
      const hds = fixture.debugElement.injector.get(DataServiceService);
      const saveSpy = spyOn(hds, 'getloginData').and.callThrough();
      click(page.submitBtn);
      expect(saveSpy.calls.any()).toBe(true, 'getloginData called');
      //expect(page.navigateSpy.calls.any()).toBe(true, 'router.navigate called');
      });
  
  });

  class Page {
    // getter properties wait to query the DOM until called.
    get buttons()     { return this.queryAll<HTMLButtonElement>('button'); }
    get submitBtn()     { return this.buttons[0]; }
    get nameDisplay() { return this.query<HTMLElement>('span'); }
    get nameInput()   { return this.query<HTMLInputElement>('input'); }
  
    gotoListSpy: jasmine.Spy;
    navigateSpy:  jasmine.Spy;
  
    constructor(fixture: ComponentFixture<LoginComponent>) {
      // get the navigate spy from the injected router spy object
      const routerSpy = <any> fixture.debugElement.injector.get(Router);
      this.navigateSpy = routerSpy.navigate;
  
      // spy on component's `gotoList()` method
      const component = fixture.componentInstance;
      this.gotoListSpy = spyOn(component, 'onLoginSubmit').and.callThrough();
    }

      //// query helpers ////
  private query<T>(selector: string): T {
    return fixture.nativeElement.querySelector(selector);
  }

  private queryAll<T>(selector: string): T[] {
    return fixture.nativeElement.querySelectorAll(selector);
  }
}

function createRouterSpy() {
  return jasmine.createSpyObj('Router', ['navigate']);
}

