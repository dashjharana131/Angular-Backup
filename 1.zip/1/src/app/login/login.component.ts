import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DataServiceService } from '../core/dataService/data-service.service'
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  alertmsg: string;
  alerttype: string;
  btnType: string;
  btnValue: string;
  showAlertMsg: boolean;
  loginId: number;
  password: string;
  loginDetails: any
  constructor(private fb: FormBuilder,private router: Router,private dataService: DataServiceService) { }

  ngOnInit() {
   
    this.loginForm = this.fb.group({
      LoginId: [''],
      Password: ['']
     
    });
    this.alertmsg = "Logged In successfully";
    this.alerttype = "danger";
    this.btnType = "success";
    this.btnValue = "Login";
    this.showAlertMsg =  false;
    this.loginId = 0;
    this.password = '';
  }
  get f() { return this.loginForm.controls; }
   async onLoginSubmit(){
    this.loginId = this.f.LoginId.value;
    this.password =  this.f.Password.value;
    console.log(this.loginId, this.password);
    this.loginDetails = await this.dataService.getloginData(this.loginId);
     if (this.loginDetails.status === 404) {
      this.showAlertMsg = true;
      this.alertmsg = "Please Register and login";
      return;
    }
    if (this.loginDetails.id != this.loginId || this.loginDetails.password != this.password) {
      this.showAlertMsg = true;
      this.alertmsg = "Invalid loginId/Password";
      return;
    }
   // this.dataService.SetItems('AdminId', this.loginDetails.adminId);
    this.router.navigateByUrl('/employees');

  }
}
