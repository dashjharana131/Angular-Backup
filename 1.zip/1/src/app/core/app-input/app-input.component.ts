import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-input',
  templateUrl: './app-input.component.html',
  styleUrls: ['./app-input.component.scss']
})
export class AppInputComponent implements OnInit {
 @Input() name: string; 
//  @Input() formControlName : string;
@Input() formGroup : FormGroup;
@Input() type: any;
  constructor() { }

  ngOnInit() {
  }

}
