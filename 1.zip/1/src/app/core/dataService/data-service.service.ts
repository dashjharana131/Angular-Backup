import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { reject } from 'q';
@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  constructor( private http: HttpClient ) { }
    url = "http://localhost:3000";
  getloginData(userId) {
    interface UserResponse {
      success: boolean;
      dataset: any;
    }
  
      return new Promise(resolve => {
      this.http.get(this.url + '/loginData/' + userId)
        .subscribe((response: HttpResponse<UserResponse>) => {
          if (response.status === 200) {
            resolve(response);
          } else {
            reject(response);
          }
        }, error => {
          resolve(error);
        }
        );
    });
  }

  getEmployeeData() {
    interface UserResponse {
      success: boolean;
      dataset: any;
    }

    return new Promise(resolve => {
      this.http.get(this.url + '/EmployeeData')
        .subscribe((response: HttpResponse<UserResponse>) => {
          resolve(response);
        }, error => {
          reject(error);
        }
        );
    });
  }
}
