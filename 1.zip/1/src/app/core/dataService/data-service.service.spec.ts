import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { DataServiceService } from './data-service.service';
import { LoginComponent } from 'src/app/login/login.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { asyncData, asyncError } from '../../../testing/async-observable-helpers';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { reject } from 'q';

const testUrl = '/http://localhost:3000/loginData/1';
interface data {
  id: 1,
  userName: "Sharmila",
  password: "sharmila",
  status: 200
}
describe('DataServiceService', () => {
  let httpClient: HttpClient;
  let httpClientSpy: { get: jasmine.Spy };
  let httpMock: HttpTestingController;
  let service: DataServiceService
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, HttpClientModule]
    })
    service = TestBed.get(DataServiceService);
    httpMock = TestBed.get(HttpTestingController);
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    service = new DataServiceService(<any>httpClientSpy);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });



  it('getLoginData() should http GET names', () => {
    const names =
    {
      id: 1,
      userName: "Sharmila",
      password: "sharmila",
      status: 200
    }

    httpClientSpy.get.and.returnValue(asyncData(names));
    service.getloginData(names.id).then(
      res => expect(res).toEqual(names),
      reject
    );

  });

  it('should return an error when the server returns a 404', () => {
    const errorResponse = new HttpErrorResponse({
      error: 'test 404 error',
      status: 404, statusText: 'Not Found'
    });
    const names =
    {
      id: 1,
      userName: "Sharmila",
      password: "sharmila",
      status: 200
    }
    httpClientSpy.get.and.returnValue(asyncError(errorResponse));

    service.getloginData(names.id).then(
      res => reject('expected an error, not heroes'),
      //res => expect(reject).toBeDefined(),
      error => expect(error.message).toContain('test 404 error')
    );
  });
});
