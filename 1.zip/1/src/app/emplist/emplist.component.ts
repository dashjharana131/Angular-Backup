import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../core/dataService/data-service.service'

@Component({
  selector: 'app-emplist',
  templateUrl: './emplist.component.html',
  styleUrls: ['./emplist.component.scss']
})
export class EmplistComponent implements OnInit {
  tblName: string;
  tableHeader: string[];
  tblbody: any[];
  EmpDetails: any;
  constructor(private dataService: DataServiceService) { }

  async ngOnInit() {
    this.tableHeader = ["Name", "Age", "Gender"];
    this.tblName = "EmployeeList";
    // this.tblbody = [{
    //   Name: 'Sharmila',
    //   Age: '26',
    //   Gender: 'F',
    // }]
    this.EmpDetails = await this.dataService.getEmployeeData(); 
    const headKey = Object.keys(this.EmpDetails);
    console.log( Object.keys(this.EmpDetails));
    console.log( this.EmpDetails)

  }

}
