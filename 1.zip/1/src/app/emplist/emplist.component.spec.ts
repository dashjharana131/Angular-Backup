import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmplistComponent } from './emplist.component';
import { TablesComponent } from '../core/tables/tables.component';


describe('EmplistComponent', () => {
  let component: EmplistComponent;
  let fixture: ComponentFixture<EmplistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EmplistComponent, TablesComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmplistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Values to be defined', () => {
    expect(component.tableHeader).toBeDefined();
    expect(component.tblName).toBeDefined();
    expect(component.tblbody).toBeDefined();
  });
});
