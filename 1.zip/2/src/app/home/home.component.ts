import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DataServiceService } from '../core/dataService/data-service.service'
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  homeForm: FormGroup;
  dropdownItems: any;
  selLoc: string;
  getpickUpDetails : any;
  constructor(private fb: FormBuilder, private dataService: DataServiceService) { }

  async ngOnInit() {

    this.homeForm = this.fb.group({
      YourName: [''],
      MobileNo: [''],
      Source: [''],
      Destination: [''],
      city:['']
     
    });
    this.dropdownItems = ["Name", "Age", "Gender"];
    this.dropdownItems =  await this.dataService.getlocationData();
   // this.selLoc = this.dataService.GetItems('location');
   
  }

  async onchangedata(data) {
   this.selLoc = data.target.value;
   this.getpickUpDetails = await this.dataService.getpickUpDetails(this.selLoc);
   this.getpickUpDetails = this.getpickUpDetails.address;
   console.log(this.getpickUpDetails);
  }
  public saveCode(e): void {
    let name = e.target.value;
    let list = this.getpickUpDetails.filter(x => x.address === name)[0];
    console.log(list);
  }
  onGetEstimate(){

    this.selLoc = this.dataService.GetItems('location');
alert(this.selLoc);
  }
}
