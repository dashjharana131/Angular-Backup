/*
inBuilt modules
*/
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
/*
components and  modules
*/
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
/*
ngBootstrap
*/
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
/*
Reusable componenets
*/
import { AppInputComponent } from './core/app-input/app-input.component';
import { HeaderComponent } from './core/header/header.component';
import { TablesComponent } from './core/tables/tables.component';
import { AlertMessageComponent } from './core/alert-message/alert-message.component';
import { DropdownComponent } from './core/dropdown/dropdown.component';

@NgModule({
  declarations: [
    AppComponent,
    AppInputComponent,
    HeaderComponent,
    TablesComponent,
    AlertMessageComponent,
    HomeComponent,
    DropdownComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
