import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../services/myservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Group } from '../entry/user';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  username: any;
  groups: Group;
  showMenu: boolean;
  login: boolean;
  message: any;
  subscription: Subscription;


  constructor(private myservice: MyserviceService, private route: ActivatedRoute, private router: Router) {
    // subscribe to home component messages
    this.subscription = this.myservice.getMessage().subscribe(message => { this.message = message; });
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
  }
  isavailable = false;

  ngOnInit() {
    this.getLocalStorage();
  }

  /* Functoin to get local storage */
  getLocalStorage() {
    if (localStorage.getItem("UserDetails") != null) {
      let localUser = localStorage.getItem("UserDetails");
      this.username = JSON.parse(localUser).username;
      this.showMenu = true;
      this.login = false;
    }
    else {
      this.showMenu = false;
      this.login = true;
    }
  }


  /* Function is for to logout */
  logout() {
    if (confirm("Do you really wants to logout?")) {
      localStorage.removeItem("UserDetails");
      this.router.navigateByUrl("login");
    }
  }
}
