import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService } from '../services/myservice.service';
import { Group } from '../entry/user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  username: any;
  showMenu: boolean;
  login: boolean;

  constructor(private router: Router, private myservice: MyserviceService) { }

  groups;
  isgroups;
  isavailable = false;
  groupId: number;
  hid: number;
  groupStatus = false;
  groupList: Group[];
  selectedGrp: Group;
  //show: boolean = true;

  ngOnInit() {
    this.myservice.getgrp().subscribe(groups => {
      // console.log(groups);
      this.groups = groups;
      this.isgroups = true;
      this.isavailable = true;
    });
    this.getLocalStorage();
  }

  joingrp(data: Group) {
    if (confirm('Are you Sure you want to join this group')) {
      this.selectedGrp = data;
      if (this.selectedGrp) {
        console.log(this.selectedGrp);
        this.isavailable = false;
        alert("You joined");
      }
      this.router.navigateByUrl("home");
    }
  }

  getLocalStorage() {
    if (localStorage.getItem("UserDetails") != null) {
      let localUser = localStorage.getItem("UserDetails");
      this.username = JSON.parse(localUser).username;
      this.showMenu = true;
      this.login = false;
    }
    else {
      this.showMenu = false;
      this.login = true;
    }
  }

  sendMessage(): void {
    // send message to subscribers via observable subject
    this.myservice.sendMessage('Message from Home Component to App Component!');
  }

  clearMessage(): void {
    // clear message
    this.myservice.clearMessage();
  }

  /* Function is for to logout */
  logout() {
    if (confirm("Do you really wants to logout?")) {
      localStorage.removeItem("UserDetails");
      this.router.navigateByUrl("login");
    }
  }
}
