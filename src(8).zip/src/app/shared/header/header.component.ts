import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  username: any;
  showMenu: boolean;
  login: boolean;

  constructor() { }
  isLoggedIn = false;

  ngOnInit() {
    this.getLocalStorage();
  }

  getLocalStorage() {
    if (localStorage.getItem("UserDetails") != null) {
      let localUser = localStorage.getItem("UserDetails");
      this.username = JSON.parse(localUser).username;
      this.showMenu = true;
      this.login = false;
    }
    else {
      this.showMenu = false;
      this.login = true;
    }
  }
  
  // logOut() {
  //   localStorage.removeItem("UserDetails");
  //   this._router.navigateByUrl("/login");
  // }
}
