import { Injectable } from '@angular/core';
import { User } from '../entry/user';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  BASE_URL = "http://localhost:3000/";
  private subject = new Subject<any>();
  constructor(private _http: HttpClient) { }

  /* Function is used for to send data to another component */
  sendMessage(message: string) {
    this.subject.next({ message });
  }

  clearMessage() {
    this.subject.next();
  }

  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }

  // /* Function is used for to Get data to another component */
  // getHistory(): Observable<any> {
  //   return this.subject.asObservable();
  // }

  /* Function is used for to get registered users */
  getreg() {
    return this._http.get(this.BASE_URL + 'register');
  }

  /* Function is used for to get groups */
  getgrp() {
    return this._http.get(this.BASE_URL + 'socialGrps');
  }

  /* Function is used for to get history */
  getHistory() {
    return this._http.get(this.BASE_URL + 'socialGrps');
  }

  /* Function is used for to register the new user */
  onSubmit(user: User) {
    return this._http.post(this.BASE_URL + 'register', user)
  }
}
