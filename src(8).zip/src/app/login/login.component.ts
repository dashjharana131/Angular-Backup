import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MyserviceService } from '../services/myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userform: FormGroup;
  users;
  error: boolean;

  constructor(private fb: FormBuilder, private _service: MyserviceService, private _router: Router) {
    this.userform = this.fb.group({
      'uname': new FormControl('', Validators.required),
      'password': new FormControl('', Validators.compose([Validators.required, Validators.minLength(6)]))
    });
  }

  ngOnInit() {
    this._service.getreg().subscribe(res => { console.log(res); this.users = res })
  }

  onSubmit() {
    for (var i = 0; i < this.users.length; i++) {
      if ((this.users[i].username === this.userform.value.uname) && (this.users[i].password === this.userform.value.password)) {
        this.error = false;
        localStorage.setItem("UserDetails", JSON.stringify(this.users[i]));
        this._router.navigate(["/home"]);
      }
    }
    this.error = true;
  }
}