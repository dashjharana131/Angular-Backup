import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { MyserviceService } from '../services/myservice.service'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [MessageService]
})
export class RegisterComponent implements OnInit {
  registerform: FormGroup;
  gender;

  constructor(private fb: FormBuilder, private messageService: MessageService, private _service: MyserviceService) { }

  ngOnInit() {
    this.registerform = this.fb.group({
      'firstname': new FormControl('', Validators.required),
      'lastname': new FormControl('', Validators.required),
      'username': new FormControl('', Validators.required),
      'password': new FormControl('', Validators.compose([Validators.required, Validators.minLength(6)])),
    });
  }

  /* This function is for to register new user */
  onSubmit(value: string) {
    this._service.onSubmit(this.registerform.value).subscribe(res => { console.log(res) });
    this.messageService.add({ severity: 'info', summary: 'Success', detail: 'User Registered successfully' });
    this.registerform.reset();
  }
}
