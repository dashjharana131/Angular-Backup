export class Pizza {
  id: number;
  name: string;
  init: string;
  pizza: string;
  image: string;
  price: number;
  base: string;
  type: string;
}