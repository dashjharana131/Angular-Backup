import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizza-header',
  templateUrl: './pizza-header.component.html',
  styleUrls: ['./pizza-header.component.css']
})
export class PizzaHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
