export interface Users {
    id: number;
    username: string;
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    gender: string;
}
export interface Userdetails {
    id: number;
    name: string;
}
export interface Groups {
    id: number;
    name: string;
}
export interface Usergroup {
    id: number;
    groupname: string;
    groupid: number;
    userid: number;
}
export interface Groupmessage {
    id: number;
    message: string;
    username: string;
    userid: number;
    date: string;
}
