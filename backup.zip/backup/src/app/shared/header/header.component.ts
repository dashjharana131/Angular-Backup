import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MessageService } from '../../service/message.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  subcription: Subscription;
  userDetails: any;
  constructor(
    private router: Router,
    private messageService: MessageService
  ) { }

  ngOnInit() {
    this.getLoginUser();
  }
  getLoginUser(): void {
    this.subcription = this.messageService.getMessage().subscribe(userData => {
      if (userData) {
        this.userDetails = userData;
      } else {
        this.userDetails = {};
      }
    });
  }
  logout() {
    sessionStorage.clear();
    this.messageService.clearMessage();
    this.router.navigate(['/login']);
  }
  ngOnDestroy() {
    this.subcription.unsubscribe();
  }

}
