import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AuthGuardService } from '../service/auth-guard.service';
import { ServiceService } from '../service/service.service';
import { UrlConfigService } from '../service/url-config.service';
import { AlertComponent } from './alert/alert.component';
import { SpinnerComponent } from './spinner/spinner.component';

@NgModule({
  declarations: [HeaderComponent, FooterComponent, AlertComponent, SpinnerComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [AuthGuardService, ServiceService, UrlConfigService],
  exports: [
    HeaderComponent, FooterComponent,
    FormsModule, ReactiveFormsModule,
    AlertComponent, SpinnerComponent
  ]
})
export class SharedModule { }
