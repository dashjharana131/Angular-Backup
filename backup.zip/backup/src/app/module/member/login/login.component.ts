import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { ServiceService } from '../../../service/service.service';
import { UrlConfigService } from '../../../service/url-config.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isSubmitted = false;
  spinner = false;
  constructor(
    private elementref: ElementRef,
    private fb: FormBuilder,
    private router: Router,
    private api: ServiceService,
    private url: UrlConfigService
  ) { }

  createForm() {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
  get login() {
    return this.loginForm.controls;
  }
  ngOnInit() {
    // tslint:disable-next-line: max-line-length
    this.elementref.nativeElement.ownerDocument.body.style.background = 'linear-gradient(to right bottom, #cfcbc9 ,#ff6200,#ff6200,#cfcbc9) fixed center';
    this.createForm();
  }
  loginSubmit() {
    this.spinner = true;
    this.isSubmitted = true;
    if (this.loginForm.valid) {
      const urlString = '?username=' + this.loginForm.value.username +
        '&password=' + this.loginForm.value.password;
      this.spinner = false;
      this.api.getCallList(this.url.urlConfig().userLogin.concat(urlString)).subscribe(user => {
        console.log(user);
        if (user.length) {
          const userDetails = {
            id: user[0].id,
            name: user[0].firstname
          };
          sessionStorage.setItem('currentUser', JSON.stringify(userDetails));
          this.router.navigate(['/home']);
        } else {
          console.log('Error');
          this.api.alertConfig = this.api.modalConfig('Error', 'User Name or Password is Incorrect', true);
        }
      }, error => {
        this.spinner = false;
      });
    }
  }
}
