import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MemberRoutingModule } from './member-routing.module';
import { memberRoutingComponent } from './member-routing.module';
import { SharedModule } from '../../shared/shared.module';



@NgModule({
  declarations: [memberRoutingComponent],
  imports: [
    CommonModule,
    MemberRoutingModule,
    SharedModule
  ]
})
export class MemberModule { }
