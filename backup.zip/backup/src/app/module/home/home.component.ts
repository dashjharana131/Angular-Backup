import { Component, OnInit, ElementRef } from '@angular/core';
import { Router } from '@angular/router';

import { ServiceService } from '../../service/service.service';
import { UrlConfigService } from '../../service/url-config.service';
import { Userdetails, Usergroup, Groups } from '../../models/model';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userDetails: Userdetails;
  constructor(
    private elementref: ElementRef,
    private router: Router,
    private api: ServiceService,
    private url: UrlConfigService
  ) { }

  getUserLogin() {
    const user = JSON.parse(sessionStorage.getItem('currentUser'));
    console.log(user);
    this.userDetails = user;
  }
  ngOnInit() {
    // tslint:disable-next-line: max-line-length
    this.elementref.nativeElement.ownerDocument.body.style.background = '';
    this.getUserLogin();
  }

}
