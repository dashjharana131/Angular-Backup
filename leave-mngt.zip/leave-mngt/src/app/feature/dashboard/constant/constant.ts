import { environment } from './../../../../environments/environment';

export class Constant {

    public static API_ENDPOINT = environment.apiUrl;
}
