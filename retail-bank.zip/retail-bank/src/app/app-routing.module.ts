import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './service/auth-guard';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import(`./module/member/member.module`).then(m => m.MemberModule)
  },
  {
    path: 'account-summary',
    loadChildren: () => import(`./module/account-summary/account-summary.module`)
    .then(m => m.AccountSummaryModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'fund-transfer',
    loadChildren: () => import(`./module/fund-transfer/fund-transfer.module`)
    .then(m => m.FundTransferModule),
   canActivate: [AuthGuard]
  },
  {
    path: 'transaction',
    loadChildren: () => import(`./module/transaction/transaction.module`)
    .then(m => m.TransactionModule),
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
