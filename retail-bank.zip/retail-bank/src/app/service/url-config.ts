import { Injectable } from '@angular/core';
@Injectable()
export class UrlConfig {
    serverConfig = false;
<<<<<<< HEAD
    private apiHost = 'http://10.117.189.61:9999/retailbanking/';
=======
    private apiHost = 'http://localhost:3000/';
    private apiTemp = 'http://10.117.189.61:9999/retailbanking/transactions/';
    private apiTemp1 = 'http://10.117.189.163:8080/retailbanking/';
    private apiTemp2 = 'http://10.117.189.197:8080/retailbanking/';
    private apiTemp3 = 'http://10.117.189.46:7766/retailbanking/';
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
    url = {};

    /* url config with url list */
    urlApi() {
        return this.url = {
<<<<<<< HEAD
            userLogin: this.apiHost + 'users/user/login',
            userRegister: this.apiHost + 'users',
            accountSummary: this.apiHost + 'transactions',
            fundTransfer: this.apiHost + 'transactions/fundTransfer',
            transactionsSummary: this.apiHost + 'transactions/monthTransaction'
=======
            userLogin: this.apiTemp1 + 'users/user/login',
            userRegister: this.apiTemp1 + 'users',
            accountSummary: this.apiTemp2 + 'transactions',
            fundTransfer: this.apiTemp + 'fundTransfer',
            transactionsSummary: this.apiTemp3 + 'monthTransaction'
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
        };
    }

    /* return url */
    urlConfig() {
        return  this.urlApi() ;
    }
}
