import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
@Injectable()

export class Service {
  alertConfig = {
    header: '',
    message: '',
    modalShow: false,
    button: ''
  };
  constructor(private http: HttpClient) { }

  /* Http Headers */
  httpOptions = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json'
    })
  };

  /* post api call  */
<<<<<<< HEAD
  public postCall(url, postData, type): Observable<any> {
=======
  postCall(url, postData, type): Observable<any> {
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
    this.alertConfigDefaultValue();
    return this.http[type](url, postData, this.httpOptions)
      .pipe(
        catchError(this.errorHandler.bind(this))
      );
  }

  /* get call */
<<<<<<< HEAD
  public getList(url: string): Observable<any> {
=======
  getList(url: string): Observable<any> {
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
    this.alertConfigDefaultValue();
    return this.http.get(url).pipe(
      retry(1),
      catchError(this.errorHandler.bind(this))
    );
  }

  /* Error handling */
  private errorHandler(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      /* Get client-side error */
      errorMessage = error.error.message;
    } else {
      /* Get server-side error */
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
<<<<<<< HEAD
    this.alertConfig = this.modalConfig('Error', error.error.message ? error.error.message : 'Network error', true, ['Ok']);
=======
    this.alertConfig = this.modalConfig('Error', error.error.message, true, ['Ok']);
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
    return throwError(errorMessage);
  }

  /* Get logged user */
  public loggedUser() {
    return JSON.parse(sessionStorage.getItem('currentUser'));
  }

  /* Check whether valid user or not  */
  public validUser() {
    if (this.loggedUser()) {
      return true;
    } else {
      return false;
    }
  }
<<<<<<< HEAD
=======
  /* Convert Date into json date response format(dd/mm/yy) */
  public convertDate(dateVal: Date) {
    const date = new Date(dateVal);
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    return [date.getFullYear().toString(), day, month].join('-');
  }
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d

  /* Set modal properities  */
  public alertConfigDefaultValue() {
    this.alertConfig = {
      header: null,
      message: null,
      modalShow: false,
      button: null
    };
  }
  /* Set modal properities  */
  public modalConfig(head, mesg, modal, btn) {
    return {
      header: head,
      message: mesg,
      modalShow: modal,
      button: btn
    };
  }
}
