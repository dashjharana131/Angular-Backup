import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

<<<<<<< HEAD

import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { MustMatch } from 'src/app/helper/must-match';
import { CustomValidation } from 'src/app/helper/validation';
import { Option } from 'src/app/model/model';
=======
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { MustMatch } from 'src/app/helper/must-match';
import { DateValidate } from 'src/app/helper/validation';
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  spinner = false;
<<<<<<< HEAD
  documentTypes: Option[];
  ageErrorFlag: string;
=======
  documentTypes = [
    { name: 'Adhaar Card', value: 'adhaar' },
    { name: 'Voter ID', value: 'voterID' },
    { name: 'Pan Card', value: 'pan' }
  ];
  accountType = [
    { name: 'Saving', value: 'saving' },
  ];
  ageErrorFlag = false;
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d

  constructor(
    private fb: FormBuilder,
    public api: Service,
    private url: UrlConfig,
    private router: Router,
<<<<<<< HEAD
    private validate: CustomValidation
=======
    private validateDate: DateValidate
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
  ) { }

  /* Form creation */
  private createForm() {
    this.registerForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      dob: ['', Validators.required],
      gender: ['male'],
      typeOfId: ['', Validators.required],
      idProofNumber: ['', Validators.required],
      mobileNumber: ['', Validators.required],
      address: ['', Validators.required],
<<<<<<< HEAD
=======
      accountType: [''],
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(8)]],
      confirmPassword: ['', Validators.required],
    }, {
      validator: MustMatch('password', 'confirmPassword')
    });
  }

  /*  Access to form fields */
  get register() {
    return this.registerForm.controls;
  }

<<<<<<< HEAD
  /* Sign up action */
  public signUp() {
    this.ageErrorFlag = '';
    this.submitted = true;
    if (this.validate.checkFutureDate(this.registerForm.value.dob, new Date())) {
      this.ageErrorFlag = 'Date should not be in the future date';
    } else if (this.registerForm.valid) {
      /* Age calculation */
      const gettingAge = this.validate.calculateAge(this.registerForm.value.dob);
      if (gettingAge < 18) {
        this.ageErrorFlag = 'Account holder age should be 18 or above';
        return;
      }

      /* Preparing the post data */
=======
  /* calculate age */
  getAge(dateString: Date) {
    const today = new Date();
    const birthDate = new Date(dateString);
    let age = today.getFullYear() - birthDate.getFullYear();
    const month = today.getMonth() - birthDate.getMonth();
    if (month < 0 || (month === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  /* Sign up action */
  public signUp() {
    this.ageErrorFlag = false;
    this.submitted = true;
    const dateError = 'Date should not be in the future';
    if (this.validateDate.checkFutureDate(this.registerForm.value.dob, new Date())) {
      this.api.alertConfig = this.api.modalConfig('Error', dateError, true, ['Ok']);
    } else if (this.registerForm.valid) {
      /* Preparing the post data */
      const gettingAge = this.getAge(this.registerForm.value.dob);
      if (gettingAge < 18) {
        this.ageErrorFlag = true;
        return;
      }
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
      const postObj = {
        firstName: this.registerForm.value.firstName,
        lastName: this.registerForm.value.lastName,
        email: this.registerForm.value.email,
        age: gettingAge,
        gender: this.registerForm.value.gender,
        typeOfId: this.registerForm.value.typeOfId.value,
        idProofNumber: this.registerForm.value.idProofNumber,
        mobileNumber: this.registerForm.value.mobileNumber,
        address: this.registerForm.value.address,
<<<<<<< HEAD
        dob: this.validate.convertDate(this.registerForm.value.dob),
=======
        dob: this.api.convertDate(this.registerForm.value.dob),
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
        password: this.registerForm.value.password,
      };
      this.spinner = true;
      /* Api call*/
      this.api.postCall(this.url.urlConfig().userRegister, JSON.stringify(postObj), 'post').subscribe(user => {
        this.spinner = false;
        if (user) {
<<<<<<< HEAD
          user.message =  user.message + ' Do you want to login?';
          this.api.alertConfig = this.api.modalConfig('Success', user, true, ['Yes', 'No']);
        }
      },
      error => {
        this.spinner = false;
      });
=======
          this.api.alertConfig = this.api.modalConfig('Success', 'Registered Successfully', true, ['Ok']);
        }
      },
        error => {
          this.spinner = false;
        });
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
    }
  }

  /* Modal Action */
  public modalAction(action: string): void {
    if (action === 'Ok') {
      this.api.alertConfigDefaultValue();
<<<<<<< HEAD
    } else if (action === 'Yes') {
      this.router.navigate(['/login']);
      this.api.alertConfigDefaultValue();
    } else {
      this.api.alertConfigDefaultValue();
      this.reset();
    }
  }
  /* form reset */
  public reset() {
    this.submitted = false;
    this.registerForm.reset();
  }
=======
      this.router.navigate(['/login']);
    }
  }

>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
  ngOnInit() {
    /* Check whether login/not */
    if (!this.api.validUser()) {
      this.router.navigate(['/register']);
    } else {
      this.router.navigate(['/account-summary']);
    }
    /* Call the form creation while on component initiation */
    this.createForm();
<<<<<<< HEAD
    /*preparing document Type */
    this.documentTypes = [
      { name: 'Adhaar Card', value: 'adhaar' },
      { name: 'Voter ID', value: 'voterID' },
      { name: 'Pan Card', value: 'pan' }
    ];
=======
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
  }

}
