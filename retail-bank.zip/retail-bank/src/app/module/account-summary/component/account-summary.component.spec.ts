import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountSummaryComponent } from './account-summary.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SharedModuleModule } from 'src/app/shared/shared-module.module';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';

describe('AccountSummaryComponent', () => {
  let component: AccountSummaryComponent;
  let fixture: ComponentFixture<AccountSummaryComponent>;
<<<<<<< HEAD
  const serviceSpy = jasmine.createSpyObj('serviceSpy', ['getList', 'validUser', 'loggedUser' ]);
=======
  let serviceSpy = jasmine.createSpyObj('serviceSpy', ['getList', 'validUser']);
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountSummaryComponent ],
      imports: [SharedModuleModule, RouterTestingModule, HttpClientTestingModule],
<<<<<<< HEAD
      providers: [ Service,
        // { provide: Service, useValue: serviceSpy },
        UrlConfig],
    })
    .compileComponents();
    // serviceSpy = TestBed.get(Service);
=======
      providers: [
        { provide: Service, useValue: serviceSpy },
        UrlConfig],
    })
    .compileComponents();
    serviceSpy = TestBed.get(Service);
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
