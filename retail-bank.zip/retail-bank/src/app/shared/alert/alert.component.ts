import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit {
<<<<<<< HEAD
  @Input() alertObj;
=======
  @Input() alertObj: any;
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
  @Output() buttonAction = new EventEmitter();
  constructor() { }

  /* Pass the button action to parent component */
  btnAction(action) {
    this.buttonAction.emit(action);
  }
<<<<<<< HEAD
  ngOnInit() {}
=======
  ngOnInit() {
  }
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d

}
