import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AlertComponent } from './alert/alert.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { Service } from '../service/service';
import { AuthGuard } from '../service/auth-guard';
import { UrlConfig } from '../service/url-config';
import { GridComponent } from './grid/grid.component';
import { PrimeModule } from './primeng-module';
<<<<<<< HEAD
import { CustomValidation } from '../helper/validation';
=======
import { DateValidate } from '../helper/validation';
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d

@NgModule({
  declarations: [AlertComponent, SpinnerComponent, GridComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    PrimeModule
  ],
<<<<<<< HEAD
  providers: [Service, AuthGuard, UrlConfig, CustomValidation],
=======
  providers: [Service, AuthGuard, UrlConfig, DateValidate],
>>>>>>> 0f8c9e982c4fa8b1bfe7708ab8662c2343c7343d
  exports: [ FormsModule,
    ReactiveFormsModule,
    AlertComponent,
    SpinnerComponent,
    GridComponent,
    PrimeModule ]
})
export class SharedModuleModule { }
