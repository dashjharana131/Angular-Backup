import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DropdownModule } from 'primeng/dropdown';
import { HttpClientModule } from '@angular/common/http';
import { DataService } from './services/data.service';
import { UrlConfig } from './services/url';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {CalendarModule} from 'primeng/calendar';
import { TableComponent } from './common/table/table.component';
import { TableModule } from 'primeng/table';
import { MessageService } from 'primeng/api';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TableComponent
  ],
  exports:[TableComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    DropdownModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CalendarModule,
    TableModule
    
  ],
  providers: [DataService, UrlConfig, MessageService],
  bootstrap: [AppComponent],
  schemas: [
    NO_ERRORS_SCHEMA,
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule { }
