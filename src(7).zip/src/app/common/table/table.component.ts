import { Component, OnInit, Input } from '@angular/core';
import { UrlConfig } from '../../services/url';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  @Input() tableData;
  selectedPlacefrom:any;
  selectedPlaceto:any;
  vehicleData: any;
  constructor(private data: DataService,
    private url: UrlConfig) { }

  ngOnInit() {
  }

 
}
