import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  alertConfig = {};

  constructor(private http: HttpClient) { }


  getdataList(url): Observable<any> {
    this.alertConfig  = {}; 
    return this.http.get(url);
  } 
}
