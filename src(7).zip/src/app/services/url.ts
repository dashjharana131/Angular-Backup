import { Injectable } from '@angular/core';

@Injectable()
export class UrlConfig {
    serverConfig = false;
    private urlHost = 'http://localhost:4200/';
    private apiHost = '';
    private url = {};
    urlMock() {
        return this.url = {
            'vehicleList': this.urlHost + './assets/vehicle.json',
            'dropdownList': this.urlHost + './assets/dropdown.json',
            'bookedList':  this.urlHost + './assets/bookedlist.json'
        }
    }
    urlApi() {
        return this.url = {
            'vehicleList': this.apiHost + '',
            'dropdownList': this.apiHost + '',
            'bookedList': this.apiHost + ''
        }
    }
    urlConfig() {
        return this.serverConfig ? this.urlApi() : this.urlMock();
    }
}