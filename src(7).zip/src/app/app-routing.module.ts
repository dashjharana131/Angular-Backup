import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  
    {
      path: 'customer',
      loadChildren: () => import(`./customer-phase/customer-phase.module`).then(m => m.CustomerPhaseModule)
    },
    {
      path: 'driver',
      loadChildren: () => import(`./driver-phase/driver-phase.module`).then(m => m.DriverPhaseModule),
    }, 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
