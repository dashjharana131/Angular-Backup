import { Component, OnInit } from '@angular/core';
import { vehicle, dropdown, bookedList } from 'src/app/models/data';
import { DataService } from 'src/app/services/data.service';
import { UrlConfig } from 'src/app/services/url';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})

export class CustomerComponent implements OnInit {
  availableFrom = new dropdown();
  availableTo = new dropdown();
  bookList = new bookedList();
  value = Date;
  // data = require('../assets/dropdown.json');
  dropdownData: any;
  bookedData: any;

  selectedPlacefrom:any;
  selectedPlaceto:any;
  selectedDate: any;
  vehicleData: any;
  constructor(private data: DataService,
    private url: UrlConfig,
    private messageService: MessageService) {
      
  }

  ngOnInit() {
    // this.dropData = this.data;
    // console.log(this.dropData)
    this.getDropdownData();
    this.getBooklistDate();

  }

  getDropdownData(): void {
    this.data.getdataList(this.url.urlConfig().dropdownList).subscribe(res => {
      console.log(res);
      this.dropdownData = res;
      this.selectedPlacefrom = res[0];
      this.selectedPlaceto = res[0];
    });
  }

  getBooklistDate(): void{
    this.data.getdataList(this.url.urlConfig().bookedList).subscribe(res => {
      console.log(res);
      this.bookedData = res;
    });
  }

  searchVehicle(){
    console.log('date',this.selectedPlacefrom,this.selectedDate);
    this.data.getdataList(this.url.urlConfig().vehicleList).subscribe(res => {
      console.log(res);
      if(res) {
        res =  res.filter(item => item.availablityFrom === this.selectedPlacefrom.availablityFrom && item.availablityTo === this.selectedPlaceto.availablityTo )
        this.vehicleData = res;
        console.log(res);
      }
    });
  }

  bookVehicle(){
    this.messageService.add({severity:'success', summary: 'Booking Confirmed', detail:'Your vehicle on the way'});
  }

  private dateConvert(){
   
  }
}
