import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerPhaseRoutingModule } from './customer-phase-routing.module';
import { CustomerComponent } from './customer/customer.component';
import {TableModule} from 'primeng/table';
import {DropdownModule} from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { CalendarModule } from 'primeng/calendar';
import {ButtonModule} from 'primeng/button';
import {ToastModule} from 'primeng/toast';

@NgModule({
  declarations: [CustomerComponent,
   
  ],
  imports: [
    CommonModule,
    CustomerPhaseRoutingModule,
    DropdownModule,
    FormsModule,
    CalendarModule,
    ButtonModule,
    TableModule,
    ToastModule
  ]
})
export class CustomerPhaseModule { }
