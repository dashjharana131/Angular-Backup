import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DriverPhaseRoutingModule } from './driver-phase-routing.module';
import { DriverComponent } from './driver/driver.component';


@NgModule({
  declarations: [DriverComponent],
  imports: [
    CommonModule,
    DriverPhaseRoutingModule
  ]
})
export class DriverPhaseModule { }
