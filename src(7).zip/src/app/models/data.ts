export class vehicle {
    name: string;
    type: string;
    vehicleNo: any;
    availablityFrom: string;
    availablityTo: string;
    amount: number;
}

export class dropdown {
    availablityFrom: string;
    availablityTo: string;
}

export class bookedList{
    name: string;
    date: string;
    vehicleNo: string;
    availablityFrom: string;
    availablityTo: string;
    amount: number;
}