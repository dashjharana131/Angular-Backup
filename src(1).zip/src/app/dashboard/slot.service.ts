import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ISlot } from './slot';

@Injectable()
export class SlotService {

    constructor(private http: HttpClient) { }

    url: string = 'http://localhost:3000/slot';

    getAllSlots(): Observable<ISlot[]> {
        return this.http.get<ISlot[]>(this.url);
    }

    updateSlotAfterRequest(s_id, data): Observable<ISlot[]> {
        return this.http.patch<ISlot[]>(this.url + '/' + s_id, data);
    }

}