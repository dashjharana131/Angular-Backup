export interface IUser {
    id: number,
    username: string,
    password: string,
    name: string,
    address: string,
    phone: string,
    role: string
}