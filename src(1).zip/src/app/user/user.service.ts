import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IUser } from './user';

@Injectable()
export class UsersService {

    constructor(private http: HttpClient) { }

    url: string = 'http://localhost:3000/users';

    userAllUser(): Observable<IUser[]> {
        return this.http.get<IUser[]>(this.url);
    }

    userLogin(userid: string): Observable<IUser[]> {
        return this.http.get<IUser[]>(this.url + '/?username=' + userid);
    }

    userRegister(data): Observable<IUser[]> {
        return this.http.post<IUser[]>(this.url, data);
    }

    getUserDetail(id): Observable<IUser[]> {
        return this.http.get<IUser[]>(this.url + '/' + id);
    }

}