import { Component, OnInit } from '@angular/core';
import { UsersService } from './user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  username: string = '';
  password: string = '';
  isError: boolean = false;

  constructor(private usersService: UsersService, private router: Router) { }

  ngOnInit() {

  }

  userLogin() {
    this.usersService.userLogin(this.username).subscribe((data) => {
      if (data.length > 0) {
        this.isError = false;
        var userObj = JSON.stringify(data);
        var userPass = JSON.parse(userObj)[0].password;

        if (userPass == this.password) {
          if (typeof (Storage) !== "undefined") {
            localStorage.setItem("user", JSON.stringify(JSON.parse(userObj)[0]));
          }
          this.router.navigate(['dashboard']);
        } else {
          this.isError = true;
        }
      } else {
        this.isError = true;
      }
    });

  }

}
