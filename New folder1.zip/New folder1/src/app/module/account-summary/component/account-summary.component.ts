import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';

import { AccountSummary, Account } from 'src/app/model/model';

@Component({
  selector: 'app-account-summary',
  templateUrl: './account-summary.component.html',
  styleUrls: ['./account-summary.component.css']
})
export class AccountSummaryComponent implements OnInit {

  accountSummaryList: AccountSummary[];
  spinner = false;
  gridColumns = [];
  pagination = false;
  sorting = true;
  pageLinks = 5;
  accountDetails: Account;
  constructor(
    private api: Service,
    private url: UrlConfig
  ) { }

  /* get list */
  private getAccountSummaryList(): void {
    this.generateGridColumn();
    this.spinner = true;
    const loggedId = this.api.loggedUser() ? this.api.loggedUser().id : null;
    const id = '/' + loggedId;
    this.api.getList(this.url.urlConfig().accountSummary.concat(id)).subscribe(summary => {
      this.spinner = false;
      if (summary.transactions) {
        this.accountSummaryList = summary.transactions;
        this.accountDetails = summary.account;
        sessionStorage.setItem('accountDetail', JSON.stringify(summary.account));
      } else {
        this.api.alertConfig = this.api.modalConfig('Success', summary.message, true, ['Ok']);
      }
    }, error => {
      this.spinner = false;
    });
  }

  /* Modal Action */
  public modalAction(action: string): void {
    if (action === 'Ok') {
      this.api.alertConfigDefaultValue();
    }
  }

  /* configure the grid columns */
  private generateGridColumn(): void {
    this.gridColumns = [
      {
        colName: 'Beneficiary Name',
        rowName: 'benefactorName',
      }, {
        colName: 'From Account',
        rowName: 'fromAccount',
      }, {
        colName: 'To Account',
        rowName: 'toAccount',
      }, {
        colName: 'Amount',
        rowName: 'amount',
      }, {
        colName: 'Transaction Date',
        rowName: 'transactionDate',
      }, {
        colName: 'Status',
        rowName: 'transactionType',
      }
    ];
  }

  ngOnInit() {
    /* get Account summary while loading the component */
    this.getAccountSummaryList();
  }

}
