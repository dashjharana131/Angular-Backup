import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountSummaryComponent } from './account-summary.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SharedModuleModule } from 'src/app/shared/shared-module.module';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';

describe('AccountSummaryComponent', () => {
  let component: AccountSummaryComponent;
  let fixture: ComponentFixture<AccountSummaryComponent>;
  const serviceSpy = jasmine.createSpyObj('serviceSpy', ['getList', 'validUser', 'loggedUser' ]);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountSummaryComponent ],
      imports: [SharedModuleModule, RouterTestingModule, HttpClientTestingModule],
      providers: [ Service,
        // { provide: Service, useValue: serviceSpy },
        UrlConfig],
    })
    .compileComponents();
    // serviceSpy = TestBed.get(Service);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
