import { Injectable } from '@angular/core';
@Injectable()
export class UrlConfig {
    serverConfig = false;
    private apiHost = 'http://10.117.189.61:9999/retailbanking/';
    url = {};

    /* url config with url list */
    urlApi() {
        return this.url = {
            userLogin: this.apiHost + 'users/user/login',
            userRegister: this.apiHost + 'users',
            accountSummary: this.apiHost + 'transactions',
            fundTransfer: this.apiHost + 'transactions/fundTransfer',
            transactionsSummary: this.apiHost + 'transactions/monthTransaction'
        };
    }

    /* return url */
    urlConfig() {
        return  this.urlApi() ;
    }
}
