import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innerbar',
  templateUrl: './innerbar.component.html',
  styleUrls: []
})
export class InnerbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
