import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { UserService } from '../../services/user.service';




@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.css'],
  providers: [UserService]
})
export class TopbarComponent implements OnInit {
  userName : any;
  password : any;

  constructor(private router: Router , private userService : UserService) { }

  userlogin(){
    this.userService.authenticateUser(this.userName, btoa(this.password))  //Encode password in base-64
    .then( authenticateUser => {
      if(authenticateUser.length >0){
        // this.router.navigate(['/dashboard']);
      }
    })
  }

  ngOnInit() {
  }

  onSubmit() {

  }
}
