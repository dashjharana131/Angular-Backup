import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Headers, Http, RequestOptions, URLSearchParams,ResponseContentType  } from '@angular/http';
import 'rxjs/add/operator/toPromise';



@Injectable({
  providedIn: 'root'
})


export class UserService {

  constructor(private http: Http) { }
  firstApiurl: string = 'http://10.117.189.34:8080/loan/mortgage/register';


  authenticateUser(username: string,password:string):Promise<any>{
    console.log('#### service: username='+username );
    let body = JSON.stringify({
                'username':username,
                'password': password      
            });
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post('/api/authenticateuser',body, options).toPromise().then(
            response => response.json() as any
        ).catch(this.handleError);
}



}