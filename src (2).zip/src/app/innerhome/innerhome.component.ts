import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innerhome',
  templateUrl: './innerhome.component.html',
  styleUrls: []
})
export class InnerhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
