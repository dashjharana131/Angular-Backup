import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';


import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { MustMatch } from 'src/app/helper/must-match';
import { CustomValidation } from 'src/app/helper/validation';
import { Option } from 'src/app/model/model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  spinner = false;
  documentTypes: Option[];
  ageErrorFlag: string;

  constructor(
    private fb: FormBuilder,
    public api: Service,
    private url: UrlConfig,
    private router: Router,
    private validate: CustomValidation
  ) { }

  /* Form creation */
  private createForm() {
    this.registerForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      dob: ['', Validators.required],
      gender: ['male'],
      typeOfId: ['', Validators.required],
      idProofNumber: ['', Validators.required],
      mobileNumber: ['', Validators.required],
      address: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(8)]],
      confirmPassword: ['', Validators.required],
    }, {
      validator: MustMatch('password', 'confirmPassword')
    });
  }

  /*  Access to form fields */
  get register() {
    return this.registerForm.controls;
  }

  /* Sign up action */
  public signUp() {
    this.ageErrorFlag = '';
    this.submitted = true;
    if (this.validate.checkFutureDate(this.registerForm.value.dob, new Date())) {
      this.ageErrorFlag = 'Date should not be in the future date';
    } else if (this.registerForm.valid) {
      /* Age calculation */
      const gettingAge = this.validate.calculateAge(this.registerForm.value.dob);
      if (gettingAge < 18) {
        this.ageErrorFlag = 'Account holder age should be 18 or above';
        return;
      }

      /* Preparing the post data */
      const postObj = {
        firstName: this.registerForm.value.firstName,
        lastName: this.registerForm.value.lastName,
        email: this.registerForm.value.email,
        age: gettingAge,
        gender: this.registerForm.value.gender,
        typeOfId: this.registerForm.value.typeOfId.value,
        idProofNumber: this.registerForm.value.idProofNumber,
        mobileNumber: this.registerForm.value.mobileNumber,
        address: this.registerForm.value.address,
        dob: this.validate.convertDate(this.registerForm.value.dob),
        password: this.registerForm.value.password,
      };
      this.spinner = true;
      /* Api call*/
      this.api.postCall(this.url.urlConfig().userRegister, JSON.stringify(postObj), 'post').subscribe(user => {
        this.spinner = false;
        if (user) {
          user.message =  user.message + ' Do you want to login?';
          this.api.alertConfig = this.api.modalConfig('Success', user, true, ['Yes', 'No']);
        }
      },
      error => {
        this.spinner = false;
      });
    }
  }

  /* Modal Action */
  public modalAction(action: string): void {
    if (action === 'Ok') {
      this.api.alertConfigDefaultValue();
    } else if (action === 'Yes') {
      this.router.navigate(['/login']);
      this.api.alertConfigDefaultValue();
    } else {
      this.api.alertConfigDefaultValue();
      this.reset();
    }
  }
  /* form reset */
  public reset() {
    this.submitted = false;
    this.registerForm.reset();
  }
  ngOnInit() {
    /* Check whether login/not */
    if (!this.api.validUser()) {
      this.router.navigate(['/register']);
    } else {
      this.router.navigate(['/account-summary']);
    }
    /* Call the form creation while on component initiation */
    this.createForm();
    /*preparing document Type */
    this.documentTypes = [
      { name: 'Adhaar Card', value: 'adhaar' },
      { name: 'Voter ID', value: 'voterID' },
      { name: 'Pan Card', value: 'pan' }
    ];
  }

}
