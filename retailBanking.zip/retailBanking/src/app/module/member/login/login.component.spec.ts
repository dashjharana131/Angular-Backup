import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { Service } from 'src/app/service/service';
import { UrlConfig } from 'src/app/service/url-config';
import { SharedModuleModule } from 'src/app/shared/shared-module.module';


describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let serviceSpy: jasmine.SpyObj<Service>;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  serviceSpy = jasmine.createSpyObj('serviceSpy', ['getList', 'validUser', 'postCall']);

  // create new instance of FormBuilder
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [SharedModuleModule, HttpClientTestingModule],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: FormBuilder, useValue: formBuilder },
        { provide: Service, useValue: serviceSpy },
        UrlConfig]
    })
      .compileComponents();
    serviceSpy = TestBed.get(Service);
    mockRouter = TestBed.get(Router);
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check ngOnInit Valid User and form creation', () => {
    serviceSpy.validUser = jasmine.createSpy().and.returnValue(true);
    component.ngOnInit();
    component.loginForm = formBuilder.group({
      mobileNumber: ['', Validators.required],
      password: ['', Validators.required]
    });
    expect(component.loginForm.valid).toBeFalsy();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/account-summary']);
  });

  it('Should check valid user while onClickSubmit', () => {
    const currentUser = {
      name: 'Mani',
      id: 1,
      accountNumber: 1234567890
    };
    const getLoginResponse = {
      userName: 'Mani',
      userId: 1,
      accountNumber: 1234567890
    };
    component.loginForm.controls.mobileNumber.setValue('1234567890');
    component.loginForm.controls.password.setValue('123345678');
    serviceSpy.postCall = jasmine.createSpy().and.returnValue({ subscribe: () => getLoginResponse });
   /*component.onClickSubmit();
    component.submitted = true;
    expect(serviceSpy.postCall).toHaveBeenCalled();
    expect(JSON.parse(sessionStorage.getItem('currentUser'))).toEqual(currentUser);
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/account-summary']); */

  });

});
