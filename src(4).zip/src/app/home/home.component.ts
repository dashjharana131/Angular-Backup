import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  shopinfo;
  shoppopup;
  display: boolean = false;

  constructor(private service: ServiceService) { }

  ngOnInit() {
    this.getShopDetails();
  }

  onRowId(obj) {
    console.log(obj)
    this.shoppopup = obj;
    this.display = true;
  }
  getShopDetails() {
    this.service.shopDetails().subscribe(res => this.shopinfo = res)
  }

}
