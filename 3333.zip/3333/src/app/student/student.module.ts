import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentRoutingModule } from './student-routing.module';
import { CreateComponent } from './create/create.component';
import { StudentComponent } from './student.component';


@NgModule({
  declarations: [CreateComponent, StudentComponent],
  imports: [
    CommonModule,
    StudentRoutingModule
  ]
})
export class StudentModule { }
