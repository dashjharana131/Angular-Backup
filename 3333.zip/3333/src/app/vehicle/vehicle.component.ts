import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Service } from '../shared-module/service/service';
import { UrlConfig } from '../shared-module/service/url-config';
import { Vehicle, Location, VehicleType } from '../model/customer';
@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.css']
})
export class VehicleComponent implements OnInit {
  vehicleForm: FormGroup;
  vehicleList: Vehicle[];
  vehicleType: VehicleType[];
  locationList: Location[];
  spinner = false;
  gridColumns = [];
  gridAction = [];
  pagination = true;
  sorting = true;
  pageLinks = 5;
  submitted = false;
  buttonName = 'Add';
  editId: number;
  vehcleAddFlag = false;
  constructor(
    private api: Service,
    private url: UrlConfig,
    private vh: FormBuilder) { }

  // Create Form
  private createForm(): void {
    this.vehicleForm = this.vh.group({
      vehicleName: ['', Validators.required],
      vehicleType: ['', Validators.required],
      vehicleNumber: ['', Validators.required],
      amount: ['', Validators.required],
      availFrom: ['', Validators.required],
      availTo: ['', Validators.required],
    });
  }
  // get location list
  private getLocation(): void {
    this.spinner = true;
    this.api.getList(this.url.urlConfig().getLocationList).subscribe(res => {
      if (res) {
        this.spinner = false;
        this.locationList = res;
      }
    }, error => {
      this.spinner = false;
    });
  }

  // get list
  public getList(): void {
    this.generateGridColumn();
    this.spinner = true;
    this.api.getList(this.url.urlConfig().vehicleList).subscribe(res => {
      if (res) {
        this.spinner = false;
        this.vehicleList = res;
      }
    }, error => {
      this.spinner = false;
    });
  }

  // get list
  public getVehicles(): void {
    this.spinner = true;
    this.api.getList(this.url.urlConfig().vehicle).subscribe(res => {
      if (res) {
        this.spinner = false;
        this.vehicleType = res;
      }
    }, error => {
      this.spinner = false;
    });
  }

  // Modal Action
  public modalAction(action: string): void {
    if (action === 'yes') {
      this.spinner = true;
      this.addVehicle('delete');
      this.spinner = false;
    } else {
      this.api.alertConfig = {};
    }
  }
  // Add Vehicle
  public addVehicle(type: string): void {
    this.submitted = true;
    this.vehicleForm.value.id = 1;
    if (this.vehicleList && this.vehicleList.length) {
      this.vehicleForm.value.id = this.api.tofindDataId(this.vehicleList, this.vehicleList.length);
    }
    const url = type === 'Add' ? this.url.urlConfig().vehicleList : this.url.urlConfig().vehicleList + '/' + this.editId;
    const method = type === 'Add' ? 'post' : (type === 'delete' ? 'delete' : 'put');
    if (this.vehicleForm.valid) {
      this.apiAction(url, method, this.vehicleForm.value);
    } else if (method === 'delete') {
      this.apiAction(url, method, this.vehicleForm.value);
    }
  }
  // API action
  private apiAction(url: string, method: string, data: Vehicle): void {
    this.api.postCall(url, data, method).subscribe(res => {
      const mesg = method === 'Add' ? 'Added' : (method === 'delete' ? 'Deleted' : 'Updated');
      this.getList();
      this.api.alertConfig = this.api.modalConfig('Success', 'Data Successfully ' + mesg, true, ['ok']);
      this.resetForm();
      this.submitted = false;
    }, error => {
      this.spinner = false;
    });
  }
  // Populate the data while edit the vehicle
  private populateFormField(data: Vehicle): void {
    this.vehicleForm = this.vh.group({
      vehicleName: data.vehicleName,
      vehicleType: data.vehicleType,
      vehicleNumber: data.vehicleNumber,
      amount: data.amount,
      availFrom: data.availFrom,
      availTo: data.availTo,
    });
  }
  // Booking Action
  public getAction(event: any): void {
    if (event.gridAction === 'edit') {
      this.buttonName = 'Edit';
      this.populateFormField(event.val);
      this.editId = event.val.id;
      this.vehcleAddFlag = true;
    } else {
      this.editId = event.val.id;
      this.api.alertConfig = this.api.modalConfig('Cofirm', 'Are you sure want to cofirm to delete?', true, ['yes', 'no']);
    }
  }

  // Reset the form
  public resetForm(): void {
    this.vehcleAddFlag = false;
    this.vehicleForm.reset();
  }
  // convenience getter for easy access to form fields
  get vehicle() { return this.vehicleForm.controls; }

  // configure the grid columns
  private generateGridColumn(): void {
    this.gridColumns = [
      {
        colName: 'Name',
        rowName: 'vehicleName',
      }, {
        colName: 'Type',
        rowName: 'vehicleType',
      }, {
        colName: 'Vehicle Number',
        rowName: 'vehicleNumber',
      }, {
        colName: 'Avail From',
        rowName: 'availFrom',
      }, {
        colName: 'Avail To',
        rowName: 'availTo',
      }, {
        colName: 'Action',
        rowName: ['edit', 'delete'],
      }
    ];
  }
  ngOnInit() {
    this.getList();
    this.getVehicles();
    this.getLocation();
    this.createForm();
  }
}
