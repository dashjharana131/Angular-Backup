import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VehicleRoutingModule } from './vehicle-routing.module';
import { VehicleComponent } from './vehicle.component';
import { SharedModuleModule } from '../shared-module/shared-module.module';
import { MatInputModule, MatNativeDateModule} from '@angular/material';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  declarations: [VehicleComponent],
  imports: [
    CommonModule,
    VehicleRoutingModule,
    SharedModuleModule,
    MatInputModule,
    MatNativeDateModule,
    MatSelectModule
  ]
})
export class VehicleModule { }
