import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomerComponent } from './customer.component';
import { SharedModuleModule } from '../shared-module/shared-module.module';
import { MatAutocompleteModule} from '@angular/material/autocomplete';
import { MatInputModule, MatNativeDateModule} from '@angular/material';
import { MatDatepickerModule} from '@angular/material/datepicker';
import { Service } from '../shared-module/service/service';
import { UrlConfig } from '../shared-module/service/url-config';


describe('CustomerComponent', () => {
  let component: CustomerComponent;
  let fixture: ComponentFixture<CustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerComponent ],
      imports: [SharedModuleModule,
        MatAutocompleteModule,
        NoopAnimationsModule,
        MatInputModule,
        MatDatepickerModule,
        MatNativeDateModule],
        providers: [Service, UrlConfig]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
