import { Component, OnInit, OnDestroy } from '@angular/core';
import { Service } from '../shared-module/service/service';
import { UrlConfig } from '../shared-module/service/url-config';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';
import { Vehicle, Booked, Location, Action } from '../model/customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit  {
  submitted = false;
  fromLocationList: Location[];
  vehicleList: Vehicle[];
  booked: Booked[];
  toLocationList: Location[];
  spinner = false;
  gridColumns = [];
  filterForm: FormGroup;
  fromLocation: Observable<Location[]>;
  toLocation: Observable<Location[]>;
  gridAction = ['book'];
  gridEvent: any;
  todaydate: Date = new Date();
  constructor(
    private fb: FormBuilder,
    private api: Service,
    private url: UrlConfig) { }

  // Create Form
  private createForm(): void {
    this.filterForm = this.fb.group({
      locationFrom: ['', Validators.required],
      locationTo: ['', Validators.required],
      date: ['', Validators.required]
    });
  }
  // get location list
  private getLocation(): void {
    this.spinner = true;
    this.api.getList(this.url.urlConfig().getLocationList).subscribe(res => {
      if (res) {
        this.spinner = false;
        this.fromLocationList = res;
        this.toLocationList = res;
        this.filterOption('fromLocation', 'fromLocationList', 'locationFrom');
        this.filterOption('toLocation', 'toLocationList', 'locationTo');
      }
    }, error => {
      this.spinner = false;
    });
  }

  // Display the selected option value
  displayFn(data?: Location): string | undefined {
    return data ? data.display : undefined;
  }

  // Filter the option in dropdown (auto complete)
  private filterOption(list: string, listLabel: string, field: string): void {
    this[list] = this.filterForm.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value[field], listLabel))
      );
  }

  // Filter value from array of object
  private _filter(value: string, listLabel: string) {
    const filterValue = value ? value : '';
    return this[listLabel].filter((option: Location) => option.place.includes(filterValue));
  }

  // Search the vehicle while clicking on the search button
  public searchVehicle(): void {
    this.submitted = true;
    if (this.filterForm.valid) {
      const today = new Date().setHours(0, 0, 0, 0);
      const selected = new Date(this.filterForm.value.date).setHours(0, 0, 0, 0);
      if (selected < today) {
        this.api.alertConfig = this.api.modalConfig('Error', 'Date must be in the future/current', true, ['ok']);
        return;
      }
      this.getVehicleList(this.filterForm.value);
    }
  }

  // Convert Date into json date response format(dd/mm/yy)
  private convertDate(dateVal: Date) {
    const date = new Date(dateVal);
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    return [month, day, date.getFullYear().toString().substr(-2)].join('/');
  }

  // Load vehicle list through api call
  private getVehicleList(searchVal: Action): void {
    this.spinner = true;
    this.api.getList(this.url.urlConfig().vehicleList)
    .subscribe(res => {
      if (res) {
        this.spinner = false;
        const getList = res.filter((item: Vehicle) => (item.availFrom === searchVal.locationFrom.place &&
          item.availTo === searchVal.locationTo.place));
        const date = this.convertDate(searchVal.date);
        const booked = this.booked.filter((item) => (item.bookingDate === date));
        if (booked && booked.length) {
          this.findUnbookedList(getList, booked);
        } else {
          this.vehicleList = getList;
        }
      }
    }, error => {
      this.spinner = false;
      console.error(error);
    });
  }

  // Booking Action
  getAction(event: Action): void {
    if (event.gridAction === 'book') {
      this.gridEvent = event;
      this.api.alertConfig = this.api.modalConfig('Cofirm', 'Are you sure want to cofirm this booking?', true, ['yes', 'no']);
    }
  }

  // Booking the Vechicle
  bookingVehicle(): void {
    let insertId = 1;
    if (this.booked && this.booked.length) {
      insertId = this.api.tofindDataId(this.booked, this.booked.length);
    }
    const postObj = {
      vehicleName: this.gridEvent.val.vehicleName,
      bookingDate: this.convertDate(this.filterForm.value.date),
      vehicleNumber: this.gridEvent.val.vehicleNumber,
      bookedFrom: this.gridEvent.val.availFrom,
      availTo: this.gridEvent.val.availTo,
      amount: this.gridEvent.val.amount,
      id: insertId
    };
    this.api.postCall(this.url.urlConfig().bookedList, postObj, 'post').subscribe(res => {
      this.api.alertConfig = this.api.modalConfig('Success', 'Vehicle has been booked successfully', true, ['ok']);
      this.vehicleList.splice(this.vehicleList.indexOf(this.gridEvent.val), 1);
      this.getBookedList();
    }, error => {
      this.spinner = false;
    });

  }

  // To Find not booked list
  findUnbookedList(list: Vehicle[], booked: Booked[]): void {
    booked.forEach(book => {
      list.forEach((element, index) => {
        if (book.vehicleNumber === element.vehicleNumber) {
          list.splice(index, 1);
        }
      });
    });
    this.generateGridColumn();
    this.vehicleList = list;
  }

  // Get booked list
  getBookedList(): void {
    this.spinner = true;
    this.api.getList(this.url.urlConfig().bookedList).subscribe(res => {
      if (res) {
        this.spinner = false;
        this.booked = res;
      }
    }, error => {
      this.spinner = false;
    });
  }

  // configure the grid columns
  private generateGridColumn(): void {
    this.gridColumns = [
      {
        colName: 'Name',
        rowName: 'vehicleName',
      }, {
        colName: 'Type',
        rowName: 'vehicleType',
      }, {
        colName: 'Vehicle Number',
        rowName: 'vehicleNumber',
      }, {
        colName: 'Avail From',
        rowName: 'availFrom',
      }, {
        colName: 'Avail To',
        rowName: 'availTo',
      }, {
        colName: 'Price',
        rowName: 'amount',
      }, {
        colName: 'Action',
        rowName: ['book'],
      }
    ];
  }

  // convenience getter for easy access to form fields
  get customer() { return this.filterForm.controls; }

  // Modal Action
  modalAction(action: string): void {
    if (action === 'yes') {
      this.spinner = true;
      this.bookingVehicle();
      this.spinner = false;
    } else {
      this.api.alertConfig = {};
    }
  }

  // Initiate the fuction while loading the component
  ngOnInit() {
    this.generateGridColumn();
    this.createForm();
    this.getLocation();
    this.getBookedList();
  }

}
