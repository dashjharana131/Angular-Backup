import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerComponent } from './customer.component';
import { SharedModuleModule } from '../shared-module/shared-module.module';
import { MatAutocompleteModule} from '@angular/material/autocomplete';
import { MatInputModule, MatNativeDateModule} from '@angular/material';
import { MatDatepickerModule} from '@angular/material/datepicker';

@NgModule({
  declarations: [ CustomerComponent ],
  imports: [
    CommonModule,
    CustomerRoutingModule,
    SharedModuleModule,
    MatAutocompleteModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  providers: [
    MatDatepickerModule
  ],
})
export class CustomerModule { }
