import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
    path: '',
    loadChildren: () => import(`./customer/customer.module`).then(m => m.CustomerModule)
  },
  {
    path: 'customer',
    loadChildren: () => import(`./customer/customer.module`).then(m => m.CustomerModule)
  },
  {
    path: 'vehicle',
    loadChildren: () => import(`./vehicle/vehicle.module`).then(m => m.VehicleModule)
  },
  {
    path: 'booked',
    loadChildren: () => import(`./booked/booked.module`).then(m => m.BookedModule)
  },
  {
    path: 'student',
    loadChildren: () => import(`./student/student.module`).then(m => m.StudentModule)
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
