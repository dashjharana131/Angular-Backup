// Model for Vehicle list
export interface Vehicle {
    vehicleName: string;
    vehicleType: string;
    vehicleNumber: string;
    amount: number;
    availFrom: string;
    availTo: string;
}

// Model for Booked list
export interface Booked {
    id: number;
    vehicleNumber: string;
    customerId: number;
    bookingDate: string;
}

// Model for Location list
export interface Location {
    id: number;
    place: string;
    display: string;
}

// Model for Location list
export interface VehicleType {
    id: number;
    place: string;
    display: string;
}

// Model for Component method interaction
export interface Action {
    locationFrom?: Location;
    locationTo?: Location;
    date?: Date;
    gridAction?: string;
    val?: Vehicle;
}


