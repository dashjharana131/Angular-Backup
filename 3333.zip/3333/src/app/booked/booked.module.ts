import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookedRoutingModule } from './booked-routing.module';
import { BookedComponent } from './booked.component';
import { SharedModuleModule } from '../shared-module/shared-module.module';
@NgModule({
  declarations: [ BookedComponent ],
  imports: [
    CommonModule,
    BookedRoutingModule,
    SharedModuleModule
  ]
})
export class BookedModule { }
