import { Component, OnInit } from '@angular/core';
import { Service } from '../shared-module/service/service';
import { UrlConfig } from '../shared-module/service/url-config';
import { Booked } from '../model/customer';

@Component({
  selector: 'app-booked',
  templateUrl: './booked.component.html',
  styleUrls: ['./booked.component.css']
})
export class BookedComponent implements OnInit {
  bookedList: Booked[];
  spinner = true;
  gridColumns = [];
  pagination = true;
  sorting = true;
  pageLinks = 5;
  constructor(private api: Service, private url: UrlConfig) { }

   // configure the grid columns
   private generateGridColumn(): void {
    this.gridColumns = [
      {
        colName: 'Name',
        rowName: 'vehicleName',
      }, {
        colName: 'Type',
        rowName: 'bookingDate',
      }, {
        colName: 'Vehicle Number',
        rowName: 'vehicleNumber',
      }, {
        colName: 'Booked From',
        rowName: 'bookedFrom',
      }, {
        colName: 'Booked To',
        rowName: 'availTo',
      }, {
        colName: 'Price',
        rowName: 'amount',
      }
    ];
  }
  // get booked list
  private getBookedList(): void  {
    this.spinner = true;
    this.api.getList(this.url.urlConfig().bookedList).subscribe(res => {
      if (res) {
        this.spinner = false;
        this.bookedList = res;
      }
    }, error => {
      this.spinner = false;
    });
  }
  ngOnInit() {
    this.generateGridColumn();
    this.getBookedList();
  }

}
