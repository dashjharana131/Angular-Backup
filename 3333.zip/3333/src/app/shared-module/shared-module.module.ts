import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Service } from './service/service';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import {MatCardModule, MatIconModule, MatButtonModule} from '@angular/material';
import { UrlConfig } from './service/url-config';
import { HttpClientModule } from '@angular/common/http';
import { AlertComponent } from './alert/alert.component';
import { HeaderComponent } from './header/header.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { FooterComponent } from './footer/footer.component';
import { GridComponent } from './grid/grid.component';
import {TableModule} from 'primeng/table';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [AlertComponent, HeaderComponent, SpinnerComponent, FooterComponent, GridComponent],
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    TableModule,
    RouterModule,
    MatButtonModule
  ],
  providers: [Service, UrlConfig],
  exports: [MatCardModule, FormsModule,
    ReactiveFormsModule, MatIconModule,
    AlertComponent, HeaderComponent,
    SpinnerComponent, FooterComponent, GridComponent, MatButtonModule ]
})
export class SharedModuleModule { }
