import { Injectable } from '@angular/core';
@Injectable()
export class UrlConfig {
    serverConfig = true;
    private mockHost = 'http://localhost:4200/';
    private apiHost = 'http://localhost:3000/';
    private url = {};
    urlMock() {
        return this.url = {
            userLogin: this.mockHost + './assets/mock/user-list.json',
            vehicleList: this.mockHost + './assets/mock/vehicle.json',
            bookedList: this.mockHost + './assets/mock/booked.json',
            rateList: this.mockHost + './assets/mock/rate.json',
            getLocationList: this.mockHost + './assets/mock/location.json',
            vehicle: this.mockHost + '',
        };
    }
    urlApi() {
        return this.url = {
            userLogin: this.apiHost + '',
            vehicleList: this.apiHost + 'vehicles',
            editVehicle: this.apiHost + 'vehicles',
            vehicle: this.apiHost + 'vehicleTypes',
            getLocationList: this.apiHost + 'locations',
            bookedList: this.apiHost + 'booked',
            rateList: this.apiHost + '',
        };
    }
    urlConfig() {
        return this.serverConfig ? this.urlApi() : this.urlMock();
    }
}
