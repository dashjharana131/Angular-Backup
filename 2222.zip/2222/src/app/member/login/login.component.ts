import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Service } from '../../shared-module/service/service';
import { UrlConfig } from '../../shared-module/service/url-config';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  hide = true;
  loginForm: FormGroup;
  submitted = false;
  spinner = false;
  constructor(
    private fb: FormBuilder,
    private api: Service,
    private _url: UrlConfig,
    private router: Router
    ) {}
  createForm() {
    this.loginForm = this.fb.group({
      username: ['',Validators.required],
      password: ['',Validators.required]
    });
  }
  // convenience getter for easy access to form fields
  get login() { return this.loginForm.controls; }

  //Login
  onClickSubmit() {
    this.submitted = true;
    if(this.loginForm.valid) {
      this.spinner = true;
      this.api.getList(this._url.urlConfig().userLogin).subscribe(res => {
        this.spinner = false;
        if(res) {
          sessionStorage.setItem('currentUser', JSON.stringify(res));
          this.router.navigate(['/home']);
        }
      },
      error => {
        this.spinner = false;
      });
    }
  }

  ngOnInit() {
    if (!this.api.validUser()) {
      this.router.navigate(['/login']);
    } else {
      this.router.navigate(['/home']);
    }
    this.createForm();
   
  }

}
