import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Service } from '../../shared-module/service/service';
import { UrlConfig } from '../../shared-module/service/url-config';
import {MatInputModule, MatButtonModule, MatGridListModule} from '@angular/material';
import { SharedModuleModule } from 'src/app/shared-module/shared-module.module';
import { Router } from '@angular/router';
describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [SharedModuleModule,MatInputModule, MatButtonModule, MatGridListModule],
      providers: [Router,Service, UrlConfig]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
