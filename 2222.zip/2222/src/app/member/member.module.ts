import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MemberRoutingModule } from './member-routing.module';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { SharedModuleModule } from '../shared-module/shared-module.module';
import {MatInputModule, MatButtonModule} from '@angular/material';

@NgModule({
  declarations: [RegisterComponent, LoginComponent],
  imports: [
    CommonModule,
    MemberRoutingModule,
    SharedModuleModule,
    MatInputModule,
    MatButtonModule,
  ]
})
export class MemberModule { }
