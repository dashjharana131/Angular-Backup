import { Component, OnInit } from '@angular/core';
import { Service } from '../shared-module/service/service';
import { Router } from '@angular/router';
import { UrlConfig } from '../shared-module/service/url-config';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userList: any;
  spinner = false;
  gridColumns = [];
  gridAction = [];
  pagination = false;
  sorting = false;
  pageLinks = 5;

  constructor(
    private api: Service,
    private router: Router,
    private _url: UrlConfig) { }

  //get list
  public getList(event): void {
    this.generateGridColumn()
    this.spinner = true;
    this.api.getList(this._url.urlConfig().userList).subscribe(res => {
      if (res) {
        this.spinner = false;
        this.userList = res;
      }
    }, error => {
      this.spinner = false;
    });
  }

  //configure the grid columns
  private generateGridColumn(): void {
    //this.gridAction = ["edit", 'delete', 'view'];
    this.gridColumns = [
      {
        'colName': 'Name',
        'rowName': 'name',
      }, {
        'colName': 'DOB',
        'rowName': 'dob',
      }, {
        'colName': 'Gender',
        'rowName': 'gender',
      }, {
        'colName': 'Address',
        'rowName': 'address',
      }
    ];
  }

  ngOnInit() {
    if (!this.api.validUser()) {
      this.router.navigate(['/login']);
    } 
  }

}
