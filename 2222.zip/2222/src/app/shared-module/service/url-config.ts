import { Injectable } from '@angular/core';
@Injectable()
export class UrlConfig {
    serverConfig = false;
    private mockHost = 'http://localhost:4200/';
    private apiHost = '';
    private url = {};
    urlMock() {
        return this.url = {
            'userLogin': this.mockHost + './assets/mock/user.json',
            'userList': this.mockHost + './assets/mock/user-list.json'
        }
    }
    urlApi() {
        return this.url = {
            'userLogin': this.apiHost + '',
            'userList': this.mockHost + './assets/mock/user-list.json'
        }
    }
    urlConfig() {
        return this.serverConfig ? this.urlApi() : this.urlMock();
    }
    

}