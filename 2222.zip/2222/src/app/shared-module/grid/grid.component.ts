import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})

/*Grid Mandatory params*/
/***
@params() gridColumnDefinition
@params() gridData
@params() getGridData
***/

export class GridComponent implements OnInit {
  @Input() gridColumnDefinition;
  @Input() gridAction;
  @Input() gridData;
  @Input() sorting;
  @Input() pageLinks;
  @Input() pagination;
  @Output() getGridData = new EventEmitter();

  constructor() { }

  //load data from parent component
  loadData(event) {
    this.getGridData.emit(event);
  }

  ngOnInit() {
    
  }

}
