export interface IEmployee {
    name: string,
    email: string,
    mobile: string,
    add: string
}