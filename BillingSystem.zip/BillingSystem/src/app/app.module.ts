/* Angular default browser supported module */
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

/* App routing module for http url handler */
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';

/* Http client module for XMLHttpRequest */
import { HttpClientModule } from '@angular/common/http';

/* Reactive form module for handling forms & validation */
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

/* Application logic components import here */
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { InventoryComponent } from './components/inventory/inventory.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    InventoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    RouterModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
