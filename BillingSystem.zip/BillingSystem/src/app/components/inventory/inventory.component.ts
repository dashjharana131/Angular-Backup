import { Component, OnInit } from '@angular/core';
import { IProductData } from '../../models/productData';
import { ProductsService } from '../../services/products.service';
import { IProducts } from '../../models/products';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {

  products: IProducts[];

  constructor(private productsService: ProductsService) { }

  ngOnInit() {
    this.initGetAllProducts(); /*Initialize initGetAllProducts function */
  }

  /*This function is used to get all the products from json*/
  initGetAllProducts() {
    this.productsService.getAllProducts().subscribe(data => {
      console.log(data);
      this.products = data;
      console.log(this.products);
    })
  }

}
