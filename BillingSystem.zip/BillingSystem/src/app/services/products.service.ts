import { Injectable } from '@angular/core';
import { IProducts } from '../models/products';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class ProductsService {

    constructor(private http: HttpClient) {

    }

    getAllProducts(): Observable<IProducts[]> {
        let url = 'http://localhost:3000/products';
        return this.http.get<IProducts[]>(url);
    }
}