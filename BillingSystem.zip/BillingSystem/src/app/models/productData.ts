export interface IProductData {
    "productId": number,
    "productName": string,
    "productPrice": number,
    "productQuantity": number
}