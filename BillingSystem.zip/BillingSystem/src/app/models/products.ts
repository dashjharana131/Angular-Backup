import { IProductData } from '../models/productData';
export interface IProducts {
    "data": IProductData[];
}