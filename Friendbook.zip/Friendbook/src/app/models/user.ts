export class IUser {
    id: number;
    fisrtName: string;
    lastName: string;
    mobileNumber: string;
    password: string;
    email: string;
}