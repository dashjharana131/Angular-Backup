import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { MustMatch } from '../../helpers/must-match.validator';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;
  loading = false;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {

    /* Registration form validations start */
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobileNumber: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6), Validators.pattern('(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=[^0-9]*[0-9]).{8,}')]],
      confirmPassword: ['', Validators.required]
    }, {
      validator: MustMatch('password', 'confirmPassword')
    });
    /* Registration form validations end */
  }

  /* convenience getter for easy access to form fields */
  get f() {
    return this.registerForm.controls;
  }

  onRegister() {
    this.submitted = true;

    /* reset alerts on submit */
    // this.alertservice.clear();

    /* stop here if form is invalid */
    if (this.registerForm.invalid) {
      return;
    }
    this.loading = true;
    alert(this.registerForm.value.firstName + 'Registered successfully)\n\n' + JSON.stringify(this.registerForm.value))
    this.router.navigate(['/login']);

  }
}

