export const REGEX = {
    str : /^[a-zA-Z ]+$/
};
