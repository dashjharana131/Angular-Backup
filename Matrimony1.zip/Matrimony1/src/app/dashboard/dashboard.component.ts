import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  currUserAccount: any;
  url: any;
  data3: any;
  profileSummary: any;
  searchText: any;
  profileDetails: any;
  data4: any;
  gender: String;
  profileCards: any; age: number;

  // heroes = [
  //   { id: 11, name: 'Mr. Nice', country: 'India' },
  //   { id: 12, name: 'Narco' , country: 'USA'},
  //   { id: 13, name: 'Bombasto' , country: 'UK'},
  //   { id: 14, name: 'Celeritas' , country: 'Canada' },
  //   { id: 15, name: 'Magneta' , country: 'Russia'},
  //   { id: 16, name: 'RubberMan' , country: 'China'},
  //   { id: 17, name: 'Dynama' , country: 'Germany'},
  //   { id: 18, name: 'Dr IQ' , country: 'Hong Kong'},
  //   { id: 19, name: 'Magma' , country: 'South Africa'},
  //   { id: 20, name: 'Tornado' , country: 'Sri Lanka'}
  // ];
  constructor(private http: HttpClient, private route: Router) { }

  ngOnInit() {
    this.currUserAccount = sessionStorage.getItem("userId");
    this.url = `http://10.117.189.162:9800/matrimony/api/myProfile/${this.currUserAccount}`;
    this.http.get(this.url).subscribe((response) => {
      if (response) {
        this.data3 = response; debugger;
        this.profileSummary = response;
        sessionStorage.setItem('userId', response['userId'])
        console.log(response);
        
      }
    });

    // this.profileDetails = sessionStorage.getItem("userId");
  this.url = `http://10.117.189.162:9800/matrimony/api/search/20/30/male`;
  this.http.get(this.url).subscribe((response) => {
    if (response) {
      this.data4 = response; debugger;
      this.profileCards = response['user'];
      // sessionStorage.setItem('userId', response['userId'])
      console.log(response);
      
    }
  });
  }
sendRequest(){
  // var reqObj1 = {
  //           "userId": this.currUserAccount.userId,
  //           "status": this.currUserAccount.status
  //       };

  //       // return this.http.put("http://10.117.189.233:9900/modelbank/api/login", this.loginForm.value).subscribe((response)=>{
  //       //     console.log(response); debugger;
  //       //     this.route.navigate(['/accsummary']);
  //       //    // localStorage.setItem("accountNo", response.);
  //       //  }); 
  //       //   console.log(this.loginForm);
  //       this.http
  //           .put("http://10.117.189.162:9800/matrimony/api/action", this.currUserAccount.userId)
  //           .subscribe((res: Response) => {
  //               console.log(res);
  //               alert(res['message'])
  //               sessionStorage.setItem("userId", res['userId']);
  //               // this.route.navigate(['/accsummary']);

  //           }, (err) => {
  //               console.log(err)
  //               alert(err.message);
  //           });

  let data = {
    "fromAccount": sessionStorage.getItem("accountNumber"),
    "toAccount":(this.transfer.value.toAccount),
    "amount": this.transfer.value.amount
  };
  

  this.http.post('http://10.117.189.233:9900/modelbank/api/fundTransfer',data ).subscribe((response) => {
    if (response) {

      console.log(response);
      alert(response['message']);
      this.route.navigate(['/accsummary']);

    }

  });
  
}
}
