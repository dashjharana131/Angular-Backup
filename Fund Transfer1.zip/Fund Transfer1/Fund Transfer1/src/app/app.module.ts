import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule }  from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'; 
import {DialogModule} from 'primeng/dialog';
import { CreditCardDirectivesModule } from 'angular-cc-library';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { HeaderComponent } from './header/header.component';
// import { RegisterComponent } from './register/register.component';
// import { LoginComponent } from './login/login.component';
// import { AccSummaryComponent } from './acc-summary/acc-summary.component';
// import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
// import { AddpayeeComponent } from './addpayee/addpayee.component';
// import { PayeelistComponent } from './payeelist/payeelist.component';
// import { UpdatepayeeComponent } from './updatepayee/updatepayee.component';
// import { PaymentComponent } from './payment/payment.component';
// import { ConfirmotpComponent } from './confirmotp/confirmotp.component';
// import { StatementComponent } from './statement/statement.component';
// import { PurchaseComponent } from './purchase/purchase.component';
// import { CardDetailsComponent } from './card-details/card-details.component';

@NgModule({
  declarations: [
     AppComponent
    // HeaderComponent,
    // RegisterComponent,
    // LoginComponent,
    // AccSummaryComponent,
    // FundtransferComponent,
    // AddpayeeComponent,
    // PayeelistComponent,
    // UpdatepayeeComponent,
    // PaymentComponent,
    // ConfirmotpComponent,
    // StatementComponent,
    // PurchaseComponent,
    // CardDetailsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    CreditCardDirectivesModule,
    FormsModule,
    DialogModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
