import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-updatepayee',
  templateUrl: './updatepayee.component.html',
  styleUrls: ['./updatepayee.component.css']
})
export class UpdatepayeeComponent implements OnInit {
  data:any;
  updateempId:any;
  updatedatarecord :any=[]
  name:any;
  email:any;
  phone:any;
  datalength:any;
  formvalues:any;
  accountNumber: any;
  payeeName: any;
  emailId: any;
  updateForm = new FormGroup({
      controlnumber: new FormControl('',Validators.required),
      controlname: new FormControl(''),
      controlemailId: new FormControl('',)
    });
  constructor(private route:ActivatedRoute,private http:HttpClient) { 
    this.payeeName = localStorage.getItem('payeeName');
    this.accountNumber = localStorage.getItem('accountNumber');
    this.emailId = localStorage.getItem('emailId');
    
  }

  ngOnInit() {
    
  }
  onSubmit() {
    var obj ={
      "accountNumber" : 12345,
      "payeeName": this.payeeName,
      "emailId" : "abc@gmail.com"
    }
         
  this.http.put('http://192.168.43.4:9900/modelbank/api/updatePayee',obj).subscribe((response) =>{
    console.log(response); debugger;
  })
    
    }
}
