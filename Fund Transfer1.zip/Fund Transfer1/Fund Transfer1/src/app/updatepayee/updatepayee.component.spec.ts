import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatepayeeComponent } from './updatepayee.component';

describe('UpdatepayeeComponent', () => {
  let component: UpdatepayeeComponent;
  let fixture: ComponentFixture<UpdatepayeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatepayeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatepayeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
