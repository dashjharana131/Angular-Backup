import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-statement',
  templateUrl: './statement.component.html',
  styleUrls: ['./statement.component.css']
})
export class StatementComponent implements OnInit {
accountId: any;
data5: any;
creditSummary: any;
cardSummary: any;
  constructor(private http: HttpClient, private route: Router) { }

  ngOnInit() {
    this.accountId = sessionStorage.getItem("accountId");
    this.http.get(environment.baseUrl+`/modelbank/api/cardSummary/${this.accountId}`).subscribe((response) => {
      if (response) {
        this.data5 = response; 
        this.creditSummary = response.cardSummary;
        console.log(this.creditSummary); debugger;
      }
    });
  }

}
