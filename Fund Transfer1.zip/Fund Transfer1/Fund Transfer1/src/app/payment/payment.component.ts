import { Component, OnInit } from '@angular/core';
import { CreditCardValidator } from 'angular-cc-library';
import { FormGroup, FormControl, Validators,FormBuilder} from '@angular/forms';

import { Router, Route } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  form: FormGroup;
  submitted: boolean = false;
  constructor(public formBuilder:FormBuilder,private route:Router) {
    this.form = this.formBuilder.group({
      creditCard: ['',[CreditCardValidator.validateCCNumber]],
      expirationDate: ['',[CreditCardValidator.validateExpDate]],
      cvc: ['', [Validators.required, Validators.minLength(3),Validators.maxLength(4)]],
  });
  //   this.form = new FormGroup({
  //     creditCard: new FormControl('', CreditCardValidator.validateCCNumber),
  //     expirationDate: new FormControl('', CreditCardValidator.validateExpDate),
  //     cvc: new FormControl('',[Validators.required, Validators.minLength(3),Validators.maxLength(4)])
  //   });
   }

  ngOnInit() {
   
  }
  
 // convenience getter for easy access to form fields
 get f() { return this.form.controls; }
  onSubmit(form) {
    this.submitted = true;
      // stop here if form is invalid
      if (this.form.invalid) {
        return;
    }
    console.log(form);
    this.route.navigate(['/confirmotp']);
  }
}
