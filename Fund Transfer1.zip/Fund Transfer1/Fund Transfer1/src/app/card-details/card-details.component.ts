import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-card-details',
  templateUrl: './card-details.component.html',
  styleUrls: ['./card-details.component.css']
})
export class CardDetailsComponent implements OnInit {
  accountId: any;
data2: any;
cardDetails: any;
  constructor(private http: HttpClient) { }

  ngOnInit() {
  this.accountId = sessionStorage.getItem("accountId");
    this.http.get(environment.baseUrl+`/modelbank/api/CardDetails/${this.accountId}`).subscribe((response) => {
      if (response) {
        this.data2 = response; debugger;
        this.cardDetails = response;
        console.log(response);
      }
    });
  }

}
