import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Router, Route } from '@angular/router';
@Component({
  selector: 'app-confirmotp',
  templateUrl: './confirmotp.component.html',
  styleUrls: ['./confirmotp.component.css']
})
export class ConfirmotpComponent implements OnInit {

  constructor(private http:HttpClient,private route:Router) { }

  ngOnInit() {
  }
  confirm(){
  //   var otpcode = {
  //     "otp": this.otp,
  //  };
  //   this.http.post(`http://192.168.43.112:9900/modelbank/api/validateOtp/${this.payeeId}`, otpcode).subscribe((response) => {
  //    if (response) {
  //        this.data = response;
  //        alert(response['message']);
  //    }
  //   });
  //       this.route.navigate(['/fundtransfer']);
   }
}
