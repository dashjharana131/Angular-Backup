import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payeelist',
  templateUrl: './payeelist.component.html',
  styleUrls: ['./payeelist.component.css']
})
export class PayeelistComponent implements OnInit {
  data: any;
  payeeId: number;
  accountId: any;
  payeeName: String;
  accountNumber: number;
  emailId: any;
  status: String;
  ifsc: any;

  constructor(private route:Router,private http:HttpClient) { }

  ngOnInit() {
    // this.accountId= this.route.snapshot.params.data;
  this.accountId = localStorage.getItem('accountId');
   this.http.get(`http://192.168.43.15:9900/modelbank/api/ListOfPayees/${this.accountId}`).subscribe((response) => {
    if (response) {
        this.data = response;
          this.payeeId = this.data.payeeId;
          this.payeeName = this.data.payeeName;
          this.accountNumber = this.data.accountNumber;
          this.emailId = this.data.emailId;
          this.status = this.data.status;
          this.ifsc = this.data.ifsc;
    }
  
    console.log(this.data);
});
    
  }

  updatepayee( payee, email, accountumber){
      localStorage.setItem('payee',payee);
      localStorage.setItem('email',email)
      localStorage.setItem('accid', accountumber);
      this.route.navigate['/updatepayee'];
  }
  removeemp(i){
    // this.data.splice(index, 1);
    //this.id = this.route.snapshot.params.id;
    this.http.delete(`http://192.168.43.251:9900/modelbank/api/deletePayee/${this.payeeId}`).subscribe((data)=>{
         console.log("success");
    });
    
  }

}
