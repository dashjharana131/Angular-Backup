import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AccSummaryComponent } from './acc-summary/acc-summary.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PayeelistComponent } from './payeelist/payeelist.component';
import { AddpayeeComponent } from './addpayee/addpayee.component';
import { UpdatepayeeComponent } from './updatepayee/updatepayee.component';
import { PaymentComponent } from './payment/payment.component';
import { ConfirmotpComponent } from './confirmotp/confirmotp.component';
import { PurchaseComponent } from './purchase/purchase.component';
import { StatementComponent } from './statement/statement.component';
import { CardDetailsComponent } from './card-details/card-details.component';
// import { AuthGuard } from './_guards';

const routes: Routes = [
  {path: 'header', component: HeaderComponent},
  {path: 'login', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'accsummary', component: AccSummaryComponent},
  {path: 'fundtransfer', component: FundtransferComponent},
  {path: 'payeelist' , component: PayeelistComponent},
  {path: 'addpayee', component: AddpayeeComponent},
  {path: 'updatepayee', component: UpdatepayeeComponent},
  {path: 'payment', component: PaymentComponent},
  {path: 'confirmotp', component: ConfirmotpComponent},
  {path: 'purchase', component: PurchaseComponent},
  {path: 'statement', component: StatementComponent},
  {path: 'cardDetails', component: CardDetailsComponent},
  {path: '', component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
