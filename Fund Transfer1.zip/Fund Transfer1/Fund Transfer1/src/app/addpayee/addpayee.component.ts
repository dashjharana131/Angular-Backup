import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-addpayee',
  templateUrl: './addpayee.component.html',
  styleUrls: ['./addpayee.component.css']
})
export class AddpayeeComponent implements OnInit {
  payeeForm: FormGroup;
  payeeShow = false;
  loading = false;
  submitted = false;
  mylist:any = [];
  data: any;
datalength:any;
formvalues:any;
emailId: any;
ifsc: String;
otp: number;
payeeId: number;
// display: boolean = false;

// showDialog() {
//     this.display = true;
// }
  getErrorMessage() {
    return this.emailId.hasError('required') ? 'You must enter a value' :
        this.emailId.hasError('emailId') ? 'Not a valid email' :
            '';
  }
  constructor(private http:HttpClient,private route:Router,private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.payeeForm  = this.formBuilder.group({
      payeeName: new FormControl('',Validators.required),
    ifsc: new FormControl('', Validators.required),
      emailId: ['',[Validators.required,
                  Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
                  accountNumber: new FormControl('',Validators.required),
                  confirmAcc: new FormControl('',Validators.required),
                                  
      // accountNumber: this.formBuilder.group({
        // accountNumber: ['', [Validators.required, 
          // Validators.minLength(16)]],
        // confirmAcc: ['', [Validators.required, 
          // Validators.minLength(16)]],
    // }),
  })
}
  // convenience getter for easy access to form fields
  get f() { return this.payeeForm.controls; }

  onSubmit() {
      this.submitted = true;

      console.log(this.payeeForm);
      // stop here if form is invalid
      if (this.payeeForm.invalid) {
          return;
      }
      var reqObj = {
         "payeeName": this.payeeForm.value.payeeName,
         "emailId": this.payeeForm.value.emailId,
         "accountNumber" : this.payeeForm.value.accountNumber,
         "confirmAcc" : this.payeeForm.value.confirmAcc,
         "ifsc" : this.payeeForm.value.ifsc
      };
    this.http.post('http://192.168.43.112:9900/modelbank/api/addPayee/', reqObj).subscribe((response) => {
        if (response) {
            this.data = response;
            sessionStorage.setItem('accountId', response['accountId'])
            this.payeeShow = true;
            alert(response['message']);
        }
      
        console.log(this.payeeForm);
        sessionStorage.setItem('payeeId', response['payeeId'])
        
    });
  }
  show(){
    this.submitted = true;
    this.payeeShow = true;
    return this.payeeShow;
  }
  confirm(){
    var otpcode = {
      "otp": this.otp,
   };
    this.http.post(`http://192.168.43.112:9900/modelbank/api/validateOtp/${this.payeeId}`, otpcode).subscribe((response) => {
     if (response) {
         this.data = response;
         alert(response['message']);
     }
    });
        this.route.navigate(['/fundtransfer']);
  }
}