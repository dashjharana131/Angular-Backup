import { Component, OnInit } from '@angular/core';
// import { Router, ActivatedRoute, Route } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-acc-summary',
  templateUrl: './acc-summary.component.html',
  styleUrls: ['./acc-summary.component.css']
})
export class AccSummaryComponent implements OnInit {
  data2: any;
  data3: any;
  accountHistory: any;
  accountSummary: Object;
  loginId: any;
  accountNumber: number;
  url: any;cardDetails: any;
  currUserAccount: any;
  accountId: any;
  constructor(private http: HttpClient, private route: Router) { }

  ngOnInit() {
    
    this.currUserAccount = sessionStorage.getItem("accountNumber");
    this.url = environment.baseUrl+`/modelbank/api/accountSummary/${this.currUserAccount}`;
    this.http.get(this.url).subscribe((response) => {
      if (response) {
        this.data3 = response; debugger;
        this.accountSummary = response;
        sessionStorage.setItem('accountId', response['accountId'])
        localStorage.setItem('accountId', response['accountId'])
        console.log(response);
        this.getBooks();
      }
    });

  }
  getBooks() {
    this.accountId = sessionStorage.getItem("accountId");
    this.http.get(environment.baseUrl+`/modelbank/api/transactions/${this.accountId}`).subscribe((response) => {
      if (response) {
        this.data2 = response; debugger;
        this.accountHistory = response;
        console.log(response);
      }
    });
  }
  getDetails() {
    
  }
  goto() {
    this.route.navigate(['/fundtransfer']);
  }
}


