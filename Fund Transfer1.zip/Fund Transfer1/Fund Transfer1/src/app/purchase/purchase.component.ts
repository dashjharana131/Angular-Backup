import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css']
})
export class PurchaseComponent implements OnInit {
  merchantsHistory: any;
  dataHist: any;
  constructor(private http: HttpClient, private route: Router) {

}
  

  ngOnInit() {
    //this.accountId = sessionStorage.getItem("accountId");
    this.http.get(environment.baseUrl+'/modelbank/api/allMerchants').subscribe((response) => {
      if (response) {
        this.dataHist = response; debugger;
        this.merchantsHistory = response;
        console.log(response);
      }
    });  
  }

}

