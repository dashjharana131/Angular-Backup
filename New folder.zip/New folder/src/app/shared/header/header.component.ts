import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MessageService } from 'src/app/service/message-service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  subscription: Subscription;
  userDetails: any;

  constructor(
    private router: Router,
    private messageService: MessageService) {}

  /* Get loggged user details from subject subscription */
  getLoginUser(): void {
    // subscribe to home component messages
    this.subscription = this.messageService.getMessage().subscribe(userData => {
      if (userData) {
        this.userDetails = userData;
      } else {
        // clear messages when empty message received
        this.userDetails = {};
      }
    });
  }

  /* logout */
  logout(): void {
    sessionStorage.clear();
    this.messageService.clearMessages();
    this.router.navigate(['/login']);
  }
  ngOnInit() {
    this.getLoginUser();
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}
}
