export interface User {
    firstName: string;
    email: string;
    username: string;
    password: string;
    acceptTerms: boolean;
    id: number;
}