export const environment = {
  production: true
  //urlMainPath: '';
};
